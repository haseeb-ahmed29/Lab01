// Axios is a promise-based HTTP client library used in React applications to communicate with external APIs and backend servers

//Import Axios Library to make HTTP request(GET, POST, PUT, DELETE)

import axios from "axios";

const api = axios.create({
    //Set the base URL for all API requests
    baseURL: import.meta.env.VITE_API_URL || "http://localhost:5000/api",
});

export default api;