import { useState , useEffect } from "react";
import { Link } from "react-router-dom";
import api from "../services/api";

function Item() {
    const[items, setItems] = useState([])
    const[loading, setLoading] = useState("true");
    const [error, setError] = useState("")

    const token = localStorage.getItem("token");
    
 //Fetch items for logges in user:
    const fetchItems = async()=>{
        try{
            setLoading(true);
            setError("");
            const response = await api.get("/items",{
                headers:{
                    //Send JWT token in request headers for authentication
                    Authorization: `Bearer ${token}`,
                },
            });
            setItems(response.data);
        }catch(err){
            setError(err.response?.data?.message || "Failed to load item.");
        }finally{
            setLoading(false);
        }
    }


    useEffect(()=>{
    fetchItems()
},[])

//Handle item deleteion:
const handleDelete = async(id)=>{
    const confirmDelete = window.confirm("Are you sure you want to delete this item?");
    if(!confirmDelete) return;

    try{
        await api.get(`/items/${id}`,{
            headers:{
                //Send JWT token in request headers for authentication
                Authorization: `Bearer ${token}`,
            },
        });
        //Filter out deleted item from state
        setItems(items.filter((items)=>items._id !== id));
    }catch(err){
        alert(err.response?.data?.message || "Failed to delete item.")
    }
}

return (
    <div>
        <h2>My Items</h2>

        <p>
            <Link to="/add-item">
                <button>+ Add Item</button>
            </Link>
        </p>

        {error && <p style={{color: "red"}}>{error}</p>}
        {loading && <p>Loading items...</p>}

        {!loading && items.length === 0 && <p>No item found, Create your first Item...</p>}

        {!loading && items.length > 0 && (
            <table border="1" cellPadding="8" cellSpacing="0" style={{width:"100%", maxWidth:"800px"}}>
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        )}
    </div>
)
}
