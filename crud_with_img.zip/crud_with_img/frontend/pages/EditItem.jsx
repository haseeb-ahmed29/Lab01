import { useState, useEffect } from "react";
import { useParams,useNavigate, Link} from "react-router-dom";
import api from "../services/api";

function EditItem(){
    const{id} = useParams();
    const navigate = useNavigate();
    const token = localStorage.getItem("token");

    const[name, setName] = useState("");
    const[description, setDescription] = useState("");
    const[existingImage, setExistingImage]= useState("");
    const[newImage, setNewImage]= useState(null);

    const [loading, setLoading] = useState(true);
    const[submitting, setSubmitting] = useState(false);
    const [error, setError] = useState("");

    //fetch item details:
    useEffect(()=>{
    const fetchItem = async()=>{
        try{
            setLoading(true);
            const response = await api.get(`/items/${id}`,{
                headers:{
                    //Send JWT token in request headers for authentication
                    Authorization: `Bearer ${token}`,
                },
            })
            setName(response.data.name);
            setDescription(response.data.description);
            setExistingImage(response.data.image);
        }catch(err){
            setError(err.response?.data?.message || "Failed to load item details");
        }finally{
                setLoading(false);
            }
        };
        fetchItem();
}, [id, token]);
const handleSubmit =async(e)=>{
    e.preventDefault();
    setError("");
    setSubmitting(true);

    try{
        const formData = new FormData();
        formData.append("name", name);
        formData.append("description", description);

        if(newImage){
            formData.append("image", newImage);
        }
        await api.put(`/items/${id}`, formData,{
            headers:{
                //Send JWT token in request headers for authentication
                Authorization: `Bearer ${token}`,
            },
        });
        //Navigate to items list
        navigate("/items")
    }catch(err){
        setError(err.response?.data?.message || "Failed to update item");
    }finally{
        setLoading(false);
    }
}
if(loading){
    return <p>Loading Item details</p>
}
return(
    <div></div>
)

}
