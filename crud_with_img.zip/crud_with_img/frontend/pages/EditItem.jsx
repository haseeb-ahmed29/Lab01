import { useState, useEffect } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import api from "../services/api";

function EditItem() {
    const [name, setName] = useState("");
    const [description, setDescription] = useState("");
    const [existingImage, setExistingImage] = useState("");
    const [newImage, setNewImage] = useState(null);
    const [error, setError] = useState("");
    const [submitting, setSubmitting] = useState(false);
    const [loading, setLoading] = useState(true);

    const { id } = useParams();
    const navigate = useNavigate();
    const token = localStorage.getItem("token");

    // Fetch existing item details on mount
    useEffect(() => {
        const fetchItem = async () => {
            try {
                const response = await api.get(`/items/${id}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setName(response.data.name);
                setDescription(response.data.description);
                setExistingImage(response.data.image); // Assuming API returns the image URL/path
            } catch (err) {
                setError(err.response?.data?.message || "Failed to fetch item details");
            } finally {
                setLoading(false);
            }
        };

        fetchItem();
    }, [id, token]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");
        setSubmitting(true);

        try {
            const formData = new FormData();
            formData.append("name", name);
            formData.append("description", description);
            
            // Only append the new image if the user selected one
            if (newImage) {
                formData.append("image", newImage);
            }

            // Send PUT request to update the item
            await api.put(`/items/${id}`, formData, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });

            // Navigate back to items list
            navigate("/items");
        } catch (err) {
            setError(err.response?.data?.message || "Failed to update item");
        } finally {
            setSubmitting(false);
        }
    };

    if (loading) {
        return <p>Loading item data...</p>;
    }

    return (
        <div>
            <h2>Edit Item</h2>
            {error && <p style={{ color: "red" }}>{error}</p>}
            
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Item Name:</label>
                    <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                    />
                </div>
                <br />

                <div>
                    <label>Description:</label>
                    <br />
                    <textarea
                        rows="4"
                        cols="40"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        required
                    ></textarea>
                </div>
                <br />

                <div>
                    <label>Current Image</label>
                    <br />
                    {existingImage && (
                        <img 
                            src={existingImage} 
                            alt="Current Item" 
                            width="150" 
                            height="150" 
                            style={{ objectFit: "cover", margin: "8px 0" }} 
                        />
                    )}
                </div>
                <br />

                <div>
                    <label>New Image (optional):</label>
                    <input 
                        type="file" 
                        accept="image/*" 
                        onChange={(e) => setNewImage(e.target.files[0])} 
                    />
                </div>
                <br />

                <button type="submit" disabled={submitting}>
                    {submitting ? "Updating..." : "Update Item"}
                </button>{" "}
                <Link to="/items">Cancel</Link>
            </form>
        </div>
    );
}

export default EditItem;