import { useState } from "react";
import {useNavigate, Link} from "react-router-dom";
import api from "../services/api";

//Create AddItem Component:
function AddItem(){
    const[name, setName] = useState("");
    const[description, setDescription] = useState("");
    const[image, setImage]= useState(null);
    const[error, setError] = useState("");
    //State to track whether form is submitting or image is uploading
    // Initially false because nothing is being uploaded
    const [loading, setLoading] = useState(false);

    const navigate = useNavigate();
    const token = localStorage.getItem("token");

    const handleSubmit = async(e)=>{
        e.preventDefault();

        if(!image){
            setError("Please select an image File");
            return;
        }

        setError("");
        setLoading(true);

    
try{
        const formData = new FormData();
        formData.append("name", name);
        formData.append("description", description);
        formData.append("image", image);

        //Send Post request to backend APU to create a new item
        await api.post("/items", formData,{
            headers:{
                //Send JWT token in request headers for authentication
                Authorization: `Bearer ${token}`,
            },
        });

        //Navigate to items list
        navigate("/items")

    }catch(err){
        // ?. --> Chaining Operator Property: is ki value null ya undefined
        setError(err.response?.data?.message || "Failed to create item");
    }finally{
        setLoading(false);
    }

}

return (
    <div>
        <h2>Add New Item</h2>

        {/* Display error message only when error contains a value */}
        {error && <p style={{ color: "red" }}>{error}</p>}

        {/* form submission handled by handleSubmit function */}
        <form onSubmit={handleSubmit}>
            <div>
                <label>Item Name:</label>
                <input
                    type="text"
                    value={name}
                    // Update name state whenever user types
                    onChange={(e) => setName(e.target.value)}
                    required
                />
            </div>

            <br />

            <div>
                <label>Description:</label>
                <br />
                <textarea
                    rows="4"
                    cols="40"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    required
                ></textarea>
            </div>
  <br />

            <div>
                <label>Image</label>
                <input type="file"
                accept="image/*"
                onChange={(e)=> setImage(e.target.files[0])}
                required
                />
            </div>
            <br />

            <button type="submit" disabled= {loading}>
                {loading ? "Uploading & Creating.." : "Save Item"}
            </button>{" "}
            <Link to="/items">Cancel</Link>

        </form>
    </div>
)
}

export default AddItem;
       
