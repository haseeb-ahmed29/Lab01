
// What is Multer?
// Multer is Node.js middleware used in Express.js
// to handle file uploads.

// It helps the Express backend receive and process
// images or files uploaded from the React frontend.

const multer = require("multer");

// Use memory storage to upload image buffer to Cloudinary
const storage = multer.memoryStorage();

// File filter to ensure only image files are accepted
const fileFilter = (req, file, cb) => {

    // Check whether the uploaded file is an image
    if (file.mimetype.startsWith("image/")) {

        cb(null, true);

    } else {

        cb(new Error("Only image files are allowed"), false);

    }
};

// Configure Multer
const upload = multer({

    storage,

    limits: {
        fileSize: 5 * 1024 * 1024 // 5MB maximum
    },

    fileFilter

});

module.exports = upload;
