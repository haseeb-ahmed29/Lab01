
const express = require("express");
const router = express.Router();

const {
    createItem,
    getItems,
    getItemById,
    updateItem,
    deleteItem,
} = require("../controllers/itemController");

const { protect } = require("../middleware/authMiddleware");
const upload = require("../middleware/uploadMiddleware");

// All item routes are protected by authMiddleware
router.use(protect);

// All item routes for items:

// Create item
router.post("/", upload.single("image"), createItem);

// Get all items
router.get("/", getItems);

// Get single item by ID
router.get("/:id", getItemById);

// Update item
router.put("/:id", upload.single("image"), updateItem);

// Delete item
router.delete("/:id", deleteItem);

module.exports = router;
