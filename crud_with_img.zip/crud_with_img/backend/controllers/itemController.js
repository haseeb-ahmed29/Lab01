
const mongoose = require("mongoose");

const Item = require("../models/Item");

const cloudinary = require("../config/cloudinary");

// Helper function to upload an in-memory image to Cloudinary
const uploadImageToCloudinary = async (file) => {

    // Convert image buffer into Base64 string
    const b64 = Buffer.from(file.buffer).toString("base64");

    // Create Data URI
    const dataURI = `data:${file.mimetype};base64,${b64}`;

    // Upload image to Cloudinary
    const result = await cloudinary.uploader.upload(dataURI, {
        folder: "mern_items",
    });

    // Return Cloudinary result
    return result;
};


// ==========================================
// CREATE A NEW ITEM
// POST /api/items
// ==========================================

const createItem = async (req, res) => {
    try {

        const { name, description } = req.body;

        // Validate required text fields
        if (!name || !description) {
            return res.status(400).json({
                message: "Item name and description are required."
            });
        }

        // Validate image file
        if (!req.file) {
            return res.status(400).json({
                message: "Item image is required."
            });
        }

        // Upload image to Cloudinary
        const cloudinaryResult = await uploadImageToCloudinary(req.file);

        // Create item in MongoDB
        const newItem = await Item.create({
            name,
            description,
            image: cloudinaryResult.secure_url,
            cloudinary_id: cloudinaryResult.public_id,
            user: req.user._id,
        });

        return res.status(201).json({
            message: "Item Created Successfully",
            item: newItem
        });

    } catch (error) {

        console.error("Create Item Error:", error.message);

        return res.status(500).json({
            message: error.message || "Failed to create item"
        });
    }
};


// ==========================================
// GET ALL ITEMS FOR LOGGED-IN USER
// GET /api/items
// ==========================================

const getItems = async (req, res) => {
    try {

        // Only fetch items belonging to logged-in user
        const items = await Item.find({
            user: req.user._id
        }).sort({ createdAt: -1 });

        return res.status(200).json(items);

    } catch (error) {

        console.error("Get Items Error:", error.message);

        return res.status(500).json({
            message: "Failed to fetch items"
        });
    }
};


// ==========================================
// GET SINGLE ITEM BY ID
// GET /api/items/:id
// ==========================================

const getItemById = async (req, res) => {
    try {

        const { id } = req.params;

        // Validate MongoDB ObjectId
        if (!mongoose.Types.ObjectId.isValid(id)) {
            return res.status(400).json({
                message: "Invalid item ID"
            });
        }

        const item = await Item.findById(id);

        if (!item) {
            return res.status(404).json({
                message: "Item not found"
            });
        }

        // Ensure only the owner can access the item
        if (item.user.toString() !== req.user._id.toString()) {
            return res.status(403).json({
                message: "Not authorized to access this item"
            });
        }

        return res.status(200).json(item);

    } catch (error) {

        console.error("Get Item By ID Error:", error.message);

        return res.status(500).json({
            message: "Failed to fetch item"
        });
    }
};


// ==========================================
// UPDATE AN ITEM
// PUT /api/items/:id
// ==========================================

const updateItem = async (req, res) => {
    try {

        const { id } = req.params;
        const { name, description } = req.body;

        // Validate MongoDB ObjectId
        if (!mongoose.Types.ObjectId.isValid(id)) {
            return res.status(400).json({
                message: "Invalid item ID"
            });
        }

        const item = await Item.findById(id);

        if (!item) {
            return res.status(404).json({
                message: "Item not found"
            });
        }

        // Ensure only the owner can update the item
        if (item.user.toString() !== req.user._id.toString()) {
            return res.status(403).json({
                message: "Not authorized to update this item"
            });
        }

        // Update text fields if provided
        if (name !== undefined) {
            item.name = name;
        }

        if (description !== undefined) {
            item.description = description;
        }

        // If user uploads a new image
        if (req.file) {

            // Upload new image first
            const cloudinaryResult = await uploadImageToCloudinary(req.file);

            // Delete old image from Cloudinary
            if (item.cloudinary_id) {
                try {
                    await cloudinary.uploader.destroy(item.cloudinary_id);
                } catch (cleanupError) {
                    console.warn(
                        "Could not delete previous image from Cloudinary:",
                        cleanupError.message
                    );
                }
            }

            // Update image information
            item.image = cloudinaryResult.secure_url;
            item.cloudinary_id = cloudinaryResult.public_id;
        }

        // Save updated item
        const updatedItem = await item.save();

        return res.status(200).json({
            message: "Item updated successfully",
            item: updatedItem
        });

    } catch (error) {

        console.error("Update Item Error:", error.message);

        return res.status(500).json({
            message: error.message || "Failed to update item"
        });
    }
};


// ==========================================
// DELETE AN ITEM
// DELETE /api/items/:id
// ==========================================

const deleteItem = async (req, res) => {
    try {

        // Get item ID from URL
        const { id } = req.params;

        // Validate MongoDB ObjectId
        if (!mongoose.Types.ObjectId.isValid(id)) {
            return res.status(400).json({
                message: "Invalid item ID"
            });
        }

        const item = await Item.findById(id);

        if (!item) {
            return res.status(404).json({
                message: "Item not found"
            });
        }

        // Ensure only the owner can delete the item
        if (item.user.toString() !== req.user._id.toString()) {
            return res.status(403).json({
                message: "Not authorized to delete this item"
            });
        }

        // Delete image from Cloudinary
        if (item.cloudinary_id) {
            try {
                await cloudinary.uploader.destroy(item.cloudinary_id);
            } catch (cleanupError) {
                console.warn(
                    "Could not delete image from Cloudinary:",
                    cleanupError.message
                );
            }
        }

        // Delete item from MongoDB
        await Item.findByIdAndDelete(id);

        return res.status(200).json({
            message: "Item deleted Successfully"
        });

    } catch (error) {

        console.error("Delete Item Error:", error.message);

        return res.status(500).json({
            message: error.message || "Failed to delete item"
        });
    }
};


// ==========================================
// EXPORT ALL CONTROLLERS
// ==========================================

module.exports = {
    createItem,
    getItems,
    getItemById,
    updateItem,
    deleteItem
};
