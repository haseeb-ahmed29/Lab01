import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../lib/api';
import { today, displayValue, storedValue, unit } from '../../lib/format';
import { Button, Field, Select, Textarea, ErrorMessage } from '../UI';
const emptyExercise = () => ({
  name: '',
  sets: 3,
  reps: 10,
  weightKg: 0,
  distanceKm: 0,
  minutes: 0,
  notes: ''
});
export default function WorkoutForm({ item, kind, onSaved, onClose }) {
  const { user } = useAuth(),
    units = user.settings.units;
  const [form, setForm] = useState(() =>
    item
      ? {
          ...item,
          tags: item.tags.join(', '),
          exercises: item.exercises.map((e) => ({
            ...e,
            weightKg: displayValue(e.weightKg, 'lift', units),
            distanceKm:
              units === 'imperial' ? Number((e.distanceKm / 1.609344).toFixed(3)) : e.distanceKm
          }))
        }
      : {
          kind,
          title: '',
          date: today(user.settings.timezone),
          category: 'strength',
          tags: '',
          notes: '',
          status: 'completed',
          duration: 30,
          exercises: [emptyExercise()]
        }
  );
  const [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));
  const setExercise = (index, key, value) =>
    setForm((f) => ({
      ...f,
      exercises: f.exercises.map((e, i) => (i === index ? { ...e, [key]: value } : e))
    }));
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const payload = {
        ...form,
        duration: Number(form.duration),
        tags: form.tags
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean),
        exercises: form.exercises.map((exercise) => ({
          ...exercise,
          sets: Number(exercise.sets),
          reps: Number(exercise.reps),
          weightKg: storedValue(exercise.weightKg, 'lift', units),
          distanceKm:
            units === 'imperial'
              ? Number(exercise.distanceKm) * 1.609344
              : Number(exercise.distanceKm),
          minutes: Number(exercise.minutes)
        }))
      };
      await api('/workouts' + (item?._id ? '/' + item._id : ''), {
        method: item?._id ? 'PUT' : 'POST',
        body: payload
      });
      onSaved();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <form onSubmit={submit} className="form-stack">
      <Field
        label={kind === 'routine' ? 'Routine name' : 'Workout name'}
        required
        maxLength={100}
        value={form.title}
        onChange={(e) => set('title', e.target.value)}
        placeholder="e.g. Upper body strength"
      />
      <div className="form-grid">
        <Field
          label="Date"
          type="date"
          required
          value={form.date}
          onChange={(e) => set('date', e.target.value)}
        />
        <Select
          label="Category"
          value={form.category}
          onChange={(e) => set('category', e.target.value)}
        >
          {['strength', 'cardio', 'mobility', 'other'].map((v) => (
            <option key={v} value={v}>
              {v[0].toUpperCase() + v.slice(1)}
            </option>
          ))}
        </Select>
        <Field
          label="Duration (minutes)"
          type="number"
          min="0"
          max="1440"
          required
          value={form.duration}
          onChange={(e) => set('duration', e.target.value)}
        />
        {kind === 'session' && (
          <Select
            label="Status"
            value={form.status}
            onChange={(e) => set('status', e.target.value)}
          >
            <option value="completed">Completed</option>
            <option value="planned">Planned</option>
          </Select>
        )}
      </div>
      <div className="section-heading">
        <h3>Exercises</h3>
        <Button
          type="button"
          tone="quiet"
          disabled={form.exercises.length >= 40}
          onClick={() => set('exercises', [...form.exercises, emptyExercise()])}
        >
          + Add exercise
        </Button>
      </div>
      {form.exercises.map((exercise, index) => (
        <div className="entry-box" key={index}>
          <div className="entry-box-head">
            <strong>Exercise {index + 1}</strong>
            {form.exercises.length > 1 && (
              <button
                type="button"
                className="text-button danger"
                onClick={() =>
                  set(
                    'exercises',
                    form.exercises.filter((_, i) => i !== index)
                  )
                }
              >
                Remove
              </button>
            )}
          </div>
          <Field
            label="Exercise name"
            required
            maxLength={100}
            value={exercise.name}
            onChange={(e) => setExercise(index, 'name', e.target.value)}
            placeholder="e.g. Bench press"
          />
          <div className="form-grid three">
            {[
              ['sets', 'Sets', 100],
              ['reps', 'Reps', 1000],
              ['weightKg', 'Weight (' + unit('lift', units) + ')', 100000],
              ['distanceKm', 'Distance (' + (units === 'imperial' ? 'mi' : 'km') + ')', 100000],
              ['minutes', 'Minutes', 1440]
            ].map(([key, label, max]) => (
              <Field
                key={key}
                label={label}
                type="number"
                min="0"
                max={max}
                step={['sets', 'reps'].includes(key) ? '1' : 'any'}
                required
                value={exercise[key]}
                onChange={(e) => setExercise(index, key, e.target.value)}
              />
            ))}
          </div>
          <Field
            label="Exercise note (optional)"
            value={exercise.notes}
            maxLength={1500}
            onChange={(e) => setExercise(index, 'notes', e.target.value)}
          />
        </div>
      ))}
      <Field
        label="Tags (comma separated, up to 8)"
        value={form.tags}
        onChange={(e) => set('tags', e.target.value)}
        placeholder="upper body, home"
      />
      <Textarea
        label="Session notes"
        maxLength={1500}
        value={form.notes}
        onChange={(e) => set('notes', e.target.value)}
      />
      <ErrorMessage message={error} />
      <div className="form-footer">
        <Button type="button" tone="quiet" onClick={onClose}>
          Cancel
        </Button>
        <Button busy={busy} type="submit">
          {item?._id ? 'Save changes' : kind === 'routine' ? 'Save routine' : 'Save workout'}
        </Button>
      </div>
    </form>
  );
}
