import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../lib/api';
import { today, number } from '../../lib/format';
import { Button, Field, Select, Textarea, ErrorMessage } from '../UI';
const emptyFood = () => ({ name: '', quantity: '', calories: 0, protein: 0, carbs: 0, fat: 0 });
export default function MealForm({ item, onSaved, onClose }) {
  const { user } = useAuth();
  const [form, setForm] = useState(
      item || {
        date: today(user.settings.timezone),
        mealType: 'breakfast',
        notes: '',
        foods: [emptyFood()]
      }
    ),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));
  function food(index, key, value) {
    setForm((f) => ({
      ...f,
      foods: f.foods.map((v, i) => (i === index ? { ...v, [key]: value } : v))
    }));
  }
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await api('/meals' + (item ? '/' + item._id : ''), {
        method: item ? 'PUT' : 'POST',
        body: {
          ...form,
          foods: form.foods.map((f) => ({
            ...f,
            calories: Number(f.calories),
            protein: Number(f.protein),
            carbs: Number(f.carbs),
            fat: Number(f.fat)
          }))
        }
      });
      onSaved();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <form className="form-stack" onSubmit={submit}>
      <div className="form-grid">
        <Field
          label="Date"
          type="date"
          required
          value={form.date}
          onChange={(e) => set('date', e.target.value)}
        />
        <Select
          label="Meal"
          value={form.mealType}
          onChange={(e) => set('mealType', e.target.value)}
        >
          {['breakfast', 'lunch', 'dinner', 'snack'].map((v) => (
            <option key={v} value={v}>
              {v[0].toUpperCase() + v.slice(1)}
            </option>
          ))}
        </Select>
      </div>
      <p className="muted small">
        Enter nutrients for the quantity you ate. Use your food label or a trusted food database;
        totals are added automatically.
      </p>
      {form.foods.map((f, index) => (
        <div className="entry-box" key={index}>
          <div className="entry-box-head">
            <strong>Food {index + 1}</strong>
            {form.foods.length > 1 && (
              <button
                type="button"
                className="text-button danger"
                onClick={() =>
                  set(
                    'foods',
                    form.foods.filter((_, i) => i !== index)
                  )
                }
              >
                Remove
              </button>
            )}
          </div>
          <div className="form-grid">
            <Field
              label="Food name"
              required
              maxLength={100}
              value={f.name}
              onChange={(e) => food(index, 'name', e.target.value)}
              placeholder="e.g. Greek yogurt"
            />
            <Field
              label="Quantity eaten"
              required
              maxLength={80}
              value={f.quantity}
              onChange={(e) => food(index, 'quantity', e.target.value)}
              placeholder="e.g. 200 g / 1 bowl"
            />
          </div>
          <div className="form-grid four">
            {[
              ['calories', 'Calories (kcal)'],
              ['protein', 'Protein (g)'],
              ['carbs', 'Carbs (g)'],
              ['fat', 'Fat (g)']
            ].map(([key, label]) => (
              <Field
                key={key}
                label={label}
                type="number"
                min="0"
                max="100000"
                step="any"
                required
                value={f[key]}
                onChange={(e) => food(index, key, e.target.value)}
              />
            ))}
          </div>
        </div>
      ))}
      <div className="section-heading">
        <Button
          type="button"
          tone="quiet"
          disabled={form.foods.length >= 40}
          onClick={() => set('foods', [...form.foods, emptyFood()])}
        >
          + Add food
        </Button>
        <strong>
          {number(form.foods.reduce((sum, food) => sum + Number(food.calories), 0))} kcal total
        </strong>
      </div>
      <Textarea
        label="Notes (optional)"
        maxLength={1500}
        value={form.notes}
        onChange={(e) => set('notes', e.target.value)}
      />
      <ErrorMessage message={error} />
      <div className="form-footer">
        <Button type="button" tone="quiet" onClick={onClose}>
          Cancel
        </Button>
        <Button busy={busy} type="submit">
          Save meal
        </Button>
      </div>
    </form>
  );
}
