import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../lib/api';
import { today, displayValue, storedValue, unit, metricLabels } from '../../lib/format';
import { Button, Field, Select, Textarea, ErrorMessage } from '../UI';
export default function ProgressForm({ item, metric, onSaved, onClose }) {
  const { user } = useAuth(),
    units = user.settings.units;
  const [form, setForm] = useState(
      item
        ? { ...item, value: displayValue(item.value, item.metric, units) }
        : { date: today(user.settings.timezone), metric, value: '', exercise: '', notes: '' }
    ),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await api('/progress' + (item ? '/' + item._id : ''), {
        method: item ? 'PUT' : 'POST',
        body: { ...form, value: storedValue(form.value, form.metric, units) }
      });
      onSaved();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <form className="form-stack" onSubmit={submit}>
      <div className="form-grid">
        <Select
          label="Measurement"
          value={form.metric}
          onChange={(e) => setForm((f) => ({ ...f, metric: e.target.value, value: '' }))}
        >
          {Object.entries(metricLabels).map(([key, label]) => (
            <option key={key} value={key}>
              {label}
            </option>
          ))}
        </Select>
        <Field
          label="Date"
          type="date"
          required
          value={form.date}
          onChange={(e) => set('date', e.target.value)}
        />
      </div>
      <Field
        label={'Value (' + unit(form.metric, units) + ')'}
        type="number"
        min="0.01"
        step="any"
        max="100000"
        required
        value={form.value}
        onChange={(e) => set('value', e.target.value)}
      />
      {form.metric === 'lift' && (
        <Field
          label="Exercise"
          required
          value={form.exercise}
          maxLength={100}
          onChange={(e) => set('exercise', e.target.value)}
          placeholder="e.g. Bench press"
        />
      )}
      {form.metric === 'runTime' && (
        <p className="small muted">
          Use the same route or distance for comparable run times. Note the route below.
        </p>
      )}
      <Textarea
        label="Notes (optional)"
        value={form.notes}
        maxLength={1500}
        onChange={(e) => set('notes', e.target.value)}
      />
      <ErrorMessage message={error} />
      <div className="form-footer">
        <Button type="button" tone="quiet" onClick={onClose}>
          Cancel
        </Button>
        <Button busy={busy} type="submit">
          Save entry
        </Button>
      </div>
    </form>
  );
}
