import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { Button } from './UI';
export default function Modal({ title, children, onClose, wide = false }) {
  const dialog = useRef();
  useEffect(() => {
    const previous = document.activeElement;
    dialog.current.showModal();
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = '';
      previous?.focus();
    };
  }, []);
  return createPortal(
    <dialog
      ref={dialog}
      className={'modal ' + (wide ? 'wide' : '')}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onClick={(event) => {
        if (event.target === dialog.current) onClose();
      }}
      aria-label={title}
    >
      <div className="modal-head">
        <h2>{title}</h2>
        <button className="close" aria-label="Close dialog" onClick={onClose}>
          ×
        </button>
      </div>
      <div className="modal-body">{children}</div>
    </dialog>,
    document.body
  );
}
export function Confirm({ title, children, busy, onCancel, onConfirm }) {
  return (
    <Modal title={title} onClose={onCancel}>
      <p>{children}</p>
      <div className="form-footer">
        <Button tone="quiet" onClick={onCancel}>
          Cancel
        </Button>
        <Button tone="danger" busy={busy} onClick={onConfirm}>
          Delete
        </Button>
      </div>
    </Modal>
  );
}
