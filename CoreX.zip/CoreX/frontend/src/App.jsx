import { lazy, Suspense } from 'react';
import { Routes, Route, Navigate, Outlet, Link } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { Loading, ErrorMessage, Button } from './components/UI';
import AuthLayout from './layouts/AuthLayout';
import DashboardLayout from './layouts/DashboardLayout';
import { Login, Register, ForgotPassword, ResetPassword, VerifyEmail } from './pages/AuthPages';
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Workouts = lazy(() => import('./pages/Workouts'));
const Meals = lazy(() => import('./pages/Meals'));
const Progress = lazy(() => import('./pages/Progress'));
const Settings = lazy(() => import('./pages/Settings'));
const Notifications = lazy(() => import('./pages/Notifications'));
function Protected() {
  const { user } = useAuth();
  return user ? <Outlet /> : <Navigate to="/login" replace />;
}
export default function App() {
  const { loading, error, refresh } = useAuth();
  if (loading)
    return (
      <div className="boot">
        <Loading />
      </div>
    );
  if (error)
    return (
      <div className="boot">
        <div className="card">
          <h1>Let’s reconnect.</h1>
          <ErrorMessage message={error} />
          <Button onClick={refresh}>Try again</Button>
        </div>
      </div>
    );
  return (
    <Suspense fallback={<Loading />}>
      <Routes>
        <Route element={<AuthLayout />}>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/verify-email" element={<VerifyEmail />} />
        </Route>
        <Route element={<Protected />}>
          <Route element={<DashboardLayout />}>
            <Route index element={<Dashboard />} />
            <Route path="/workouts" element={<Workouts />} />
            <Route path="/meals" element={<Meals />} />
            <Route path="/progress" element={<Progress />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/notifications" element={<Notifications />} />
          </Route>
        </Route>
        <Route
          path="*"
          element={
            <div className="boot">
              <div className="card">
                <h1>Page not found.</h1>
                <p>This page is not part of your workspace.</p>
                <Link className="button primary" to="/">
                  Back to dashboard
                </Link>
              </div>
            </div>
          }
        />
      </Routes>
    </Suspense>
  );
}
