import { useState } from 'react';
import { useData } from '../hooks/useData';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { api, queryString } from '../lib/api';
import { dateLabel, displayValue, unit, metricLabels } from '../lib/format';
import {
  PageTitle,
  Button,
  Empty,
  Loading,
  ErrorMessage,
  Actions,
  Pagination
} from '../components/UI';
import { TrendChart } from '../components/Charts';
import Modal, { Confirm } from '../components/Modal';
import ProgressForm from '../components/forms/ProgressForm';
export default function Progress() {
  const { user } = useAuth(),
    toast = useToast(),
    units = user.settings.units;
  const [metric, setMetric] = useState('weight'),
    [page, setPage] = useState(1),
    [filters, setFilters] = useState({ from: '', to: '', q: '' }),
    [editing, setEditing] = useState(null),
    [deleting, setDeleting] = useState(null),
    [busy, setBusy] = useState(false);
  const { data, error, loading, reload } = useData(
    '/progress?' + queryString({ ...filters, metric, page, limit: 100 })
  );
  const values = [...(data?.items || [])]
    .reverse()
    .map((item) => ({ ...item, value: displayValue(item.value, metric, units) }));
  const exercises = [...new Set(values.map((item) => item.exercise).filter(Boolean))];
  const [chosenExercise, setChosenExercise] = useState('');
  const selectedExercise = exercises.includes(chosenExercise) ? chosenExercise : exercises[0];
  const chartValues =
    metric === 'lift' ? values.filter((item) => item.exercise === selectedExercise) : values;
  function filter(key, value) {
    setFilters((f) => ({ ...f, [key]: value }));
    setPage(1);
  }
  function saved() {
    setEditing(null);
    reload();
    toast('Progress saved.');
  }
  async function remove() {
    setBusy(true);
    try {
      await api('/progress/' + deleting._id, { method: 'DELETE' });
      setDeleting(null);
      setPage(1);
      reload();
      toast('Entry deleted.');
    } catch (e) {
      toast(e.message, 'danger');
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageTitle
        eyebrow="SEE HOW FAR YOU HAVE COME"
        title="Your progress"
        description="Track the changes that matter to you."
      >
        <Button onClick={() => setEditing({})}>+ Add entry</Button>
      </PageTitle>
      <div className="filter-bar">
        <select
          aria-label="Measurement"
          value={metric}
          onChange={(e) => {
            setMetric(e.target.value);
            setPage(1);
          }}
        >
          {Object.entries(metricLabels).map(([key, label]) => (
            <option key={key} value={key}>
              {label}
            </option>
          ))}
        </select>
        <input
          aria-label="Search exercise"
          placeholder="Search lift exercise…"
          value={filters.q}
          onChange={(e) => filter('q', e.target.value)}
        />
        <input
          aria-label="From date"
          type="date"
          value={filters.from}
          onChange={(e) => filter('from', e.target.value)}
        />
        <input
          aria-label="To date"
          type="date"
          value={filters.to}
          onChange={(e) => filter('to', e.target.value)}
        />
      </div>
      <ErrorMessage message={error} retry={reload} />
      <section className="card">
        <div className="card-head">
          <div>
            <span className="eyebrow">YOUR RECORDED TREND</span>
            <h2>{metricLabels[metric]}</h2>
          </div>
          {metric === 'lift' && exercises.length > 0 && (
            <select
              aria-label="Chart exercise"
              value={selectedExercise}
              onChange={(e) => setChosenExercise(e.target.value)}
            >
              {exercises.map((exercise) => (
                <option key={exercise}>{exercise}</option>
              ))}
            </select>
          )}
          <span className="muted small">{unit(metric, units)}</span>
        </div>
        {loading ? (
          <Loading />
        ) : (
          <TrendChart
            data={chartValues}
            label={metricLabels[metric] + ' (' + unit(metric, units) + ')'}
            target={
              metric === 'weight' && user.goals.targetWeight != null
                ? displayValue(user.goals.targetWeight, metric, units)
                : null
            }
          />
        )}
        <p className="card-note">
          Chart shows entries on this page, oldest to newest.{' '}
          {metric === 'weight'
            ? 'Set your personal target in Settings. This is not a medical assessment.'
            : metric === 'runTime'
              ? 'Compare times for the same distance or route.'
              : 'Consistent measurements make trends easier to understand.'}
        </p>
      </section>
      <section className="card">
        <div className="card-head">
          <h2>Measurement history</h2>
          <span className="muted small">{data?.total || 0} entries</span>
        </div>
        {data?.items.length ? (
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Value</th>
                  <th>Notes</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.items.map((item) => (
                  <tr key={item._id}>
                    <td>{dateLabel(item.date, { year: 'numeric' })}</td>
                    <td>
                      <strong>
                        {displayValue(item.value, metric, units)} {unit(metric, units)}
                      </strong>
                      {item.exercise && <small className="table-sub">{item.exercise}</small>}
                    </td>
                    <td className="notes-cell">{item.notes || '—'}</td>
                    <td>
                      <Actions onEdit={() => setEditing(item)} onDelete={() => setDeleting(item)} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          !loading && (
            <Empty title="No measurements yet">Add your first entry to start a trend.</Empty>
          )
        )}
      </section>
      <Pagination data={data} page={page} setPage={setPage} />
      {editing && (
        <Modal
          title={editing._id ? 'Edit measurement' : 'Record your progress'}
          onClose={() => setEditing(null)}
        >
          <ProgressForm
            item={editing._id ? editing : null}
            metric={metric}
            onSaved={saved}
            onClose={() => setEditing(null)}
          />
        </Modal>
      )}
      {deleting && (
        <Confirm
          title="Delete this entry?"
          busy={busy}
          onConfirm={remove}
          onCancel={() => setDeleting(null)}
        >
          This measurement will be permanently removed.
        </Confirm>
      )}
    </>
  );
}
