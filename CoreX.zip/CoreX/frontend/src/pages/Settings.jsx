import { useSearchParams } from 'react-router-dom';
import { PageTitle } from '../components/UI';
import AccountSettings from './settings/AccountSettings';
import Preferences from './settings/Preferences';
import Reminders from './settings/Reminders';
import Reports from './settings/Reports';
import Community from './settings/Community';
import Support from './settings/Support';
const tabs = {
  account: ['My profile', AccountSettings],
  preferences: ['Preferences & goals', Preferences],
  reminders: ['Reminders', Reminders],
  reports: ['Reports', Reports],
  community: ['Community', Community],
  support: ['Help & support', Support]
};
export default function Settings() {
  const [params, setParams] = useSearchParams();
  const tab = tabs[params.get('tab')] ? params.get('tab') : 'account',
    Content = tabs[tab][1];
  return (
    <>
      <PageTitle
        eyebrow="MAKE COREX YOURS"
        title="Settings & more"
        description="Your profile, preferences and personal goals."
      />
      <div className="settings-layout">
        <nav className="settings-nav" aria-label="Settings sections">
          {Object.entries(tabs).map(([key, [label]]) => (
            <button
              key={key}
              className={tab === key ? 'active' : ''}
              onClick={() => setParams({ tab: key })}
            >
              {label}
            </button>
          ))}
        </nav>
        <div className="settings-content">
          <Content />
        </div>
      </div>
    </>
  );
}
