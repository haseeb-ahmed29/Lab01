import { useState } from 'react';
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { Button, Field, Check, ErrorMessage } from '../components/UI';
function Intro({ title, children }) {
  return (
    <div className="auth-intro">
      <span className="eyebrow">WELCOME TO YOUR FIT ZONE</span>
      <h1>{title}</h1>
      <p>{children}</p>
    </div>
  );
}
export function Login() {
  const { authenticate, user } = useAuth(),
    navigate = useNavigate();
  const [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  if (user) return <Navigate to="/" replace />;
  async function submit(event) {
    event.preventDefault();
    const body = Object.fromEntries(new FormData(event.currentTarget));
    setBusy(true);
    setError('');
    try {
      await authenticate('login', body);
      navigate('/');
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Intro title="Good to see you.">Sign in and pick up where you left off.</Intro>
      <form onSubmit={submit} className="form-stack">
        <Field
          label="Email or username"
          name="identifier"
          autoComplete="username"
          placeholder="you@example.com"
          required
        />
        <Field
          label="Password"
          name="password"
          type="password"
          autoComplete="current-password"
          required
          maxLength={128}
        />
        <Link className="forgot-link" to="/forgot-password">
          Forgot password?
        </Link>
        <ErrorMessage message={error} />
        <Button type="submit" busy={busy} className="full">
          Sign in
        </Button>
      </form>
      <p className="auth-switch">
        New to CoreX? <Link to="/register">Create an account</Link>
      </p>
    </>
  );
}
export function Register() {
  const { authenticate, user } = useAuth(),
    navigate = useNavigate();
  const [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  if (user) return <Navigate to="/" replace />;
  async function submit(event) {
    event.preventDefault();
    const body = Object.fromEntries(new FormData(event.currentTarget));
    if (body.password !== body.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      await authenticate('register', { ...body, consent: body.consent === 'on' });
      navigate('/');
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Intro title="Your next chapter.">Create a private space for your fitness journey.</Intro>
      <form onSubmit={submit} className="form-stack">
        <div className="form-grid">
          <Field label="Full name" name="name" autoComplete="name" required maxLength={80} />
          <Field
            label="Username"
            name="username"
            autoComplete="username"
            required
            pattern="[a-zA-Z0-9_.]{3,30}"
            title="3–30 letters, numbers, dots or underscores"
          />
        </div>
        <Field label="Email address" type="email" name="email" autoComplete="email" required />
        <div className="form-grid">
          <Field
            label="Password"
            type="password"
            name="password"
            autoComplete="new-password"
            minLength={10}
            maxLength={128}
            required
            hint="At least 10 characters"
          />
          <Field
            label="Confirm password"
            type="password"
            name="confirmPassword"
            autoComplete="new-password"
            minLength={10}
            required
          />
        </div>
        <Check name="consent" required>
          I agree to store my profile and fitness entries for this tracker. My records are private;
          I can export or delete them in Settings.
        </Check>
        <ErrorMessage message={error} />
        <Button type="submit" busy={busy} className="full">
          Create account
        </Button>
      </form>
      <p className="auth-switch">
        Already have an account? <Link to="/login">Sign in</Link>
      </p>
    </>
  );
}
export function ForgotPassword() {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [message, setMessage] = useState('');
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const data = await api('/auth/forgot-password', {
        method: 'POST',
        body: Object.fromEntries(new FormData(e.currentTarget))
      });
      setMessage(data.message);
    } catch (error) {
      setError(error.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Intro title="A fresh start.">We will email you a link to reset your password.</Intro>
      {message ? (
        <div className="alert success" role="status">
          {message}
        </div>
      ) : (
        <form className="form-stack" onSubmit={submit}>
          <Field label="Email address" type="email" name="email" autoComplete="email" required />
          <ErrorMessage message={error} />
          <Button busy={busy} type="submit">
            Send reset link
          </Button>
        </form>
      )}
      <p className="auth-switch">
        <Link to="/login">Back to sign in</Link>
      </p>
    </>
  );
}
export function ResetPassword() {
  const [params] = useSearchParams();
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [message, setMessage] = useState('');
  async function submit(e) {
    e.preventDefault();
    const values = Object.fromEntries(new FormData(e.currentTarget));
    if (values.password !== values.confirmPassword) return setError('Passwords do not match.');
    setBusy(true);
    setError('');
    try {
      const data = await api('/auth/reset-password', {
        method: 'POST',
        body: { password: values.password, token: params.get('token') || '' }
      });
      setMessage(data.message);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Intro title="Choose a new password.">Make it memorable to you and hard to guess.</Intro>
      {message ? (
        <div className="alert success">{message}</div>
      ) : (
        <form className="form-stack" onSubmit={submit}>
          <Field
            label="New password"
            name="password"
            type="password"
            autoComplete="new-password"
            minLength={10}
            maxLength={128}
            required
          />
          <Field
            label="Confirm password"
            name="confirmPassword"
            type="password"
            autoComplete="new-password"
            minLength={10}
            required
          />
          <ErrorMessage message={error} />
          <Button busy={busy} type="submit">
            Update password
          </Button>
        </form>
      )}
      <p className="auth-switch">
        <Link to="/login">Back to sign in</Link>
      </p>
    </>
  );
}
export function VerifyEmail() {
  const [params] = useSearchParams(),
    { refresh } = useAuth();
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [message, setMessage] = useState('');
  async function verify() {
    setBusy(true);
    setError('');
    try {
      const data = await api('/auth/verify-email', {
        method: 'POST',
        body: { token: params.get('token') || '' }
      });
      setMessage(data.message);
      await refresh();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Intro title="Verify your email.">
        Confirm this address to receive scheduled email reminders.
      </Intro>
      <ErrorMessage message={error} />
      {message ? (
        <div className="alert success">{message}</div>
      ) : (
        <Button onClick={verify} busy={busy}>
          Verify email address
        </Button>
      )}
      <p className="auth-switch">
        <Link to="/">Go to dashboard</Link>
      </p>
    </>
  );
}
