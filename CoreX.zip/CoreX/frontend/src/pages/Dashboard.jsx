import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useData } from '../hooks/useData';
import { Badge, Button, Empty, ErrorMessage, Loading, PageTitle } from '../components/UI';
import { ActivityChart, TrendChart } from '../components/Charts';
import { displayValue, unit, number, dateLabel } from '../lib/format';
export default function Dashboard() {
  const { user } = useAuth(),
    { data, error, loading, reload } = useData('/dashboard');
  if (loading && !data) return <Loading />;
  if (error) return <ErrorMessage message={error} retry={reload} />;
  const weightData = data.progress
    .filter((item) => item.metric === 'weight')
    .map((item) => ({ ...item, value: displayValue(item.value, 'weight', user.settings.units) }));
  const progress = Math.min(100, (data.weekCount / user.goals.weeklyWorkouts) * 100);
  const calorieProgress = Math.min(100, (data.macros.calories / user.goals.dailyCalories) * 100);
  return (
    <>
      <PageTitle
        eyebrow={dateLabel(data.today, { weekday: 'long', year: 'numeric' })}
        title={'Hi, ' + user.name.split(' ')[0] + '.'}
        description="A little progress, every day."
      >
        <Link className="button primary" to="/workouts?new=1">
          + Log workout
        </Link>
      </PageTitle>
      <section className="stat-grid" aria-label="Your fitness overview">
        <article className="stat-card">
          <span>Workouts this week</span>
          <div className="stat-value">
            {data.weekCount}
            <small>/ {user.goals.weeklyWorkouts}</small>
          </div>
          <div className="meter">
            <span style={{ width: progress + '%' }} />
          </div>
          <small>
            {data.weekCount >= user.goals.weeklyWorkouts
              ? 'Weekly goal complete'
              : 'Every session counts'}
          </small>
        </article>
        <article className="stat-card">
          <span>Active time</span>
          <div className="stat-value">
            {number(data.weekDuration)}
            <small>min</small>
          </div>
          <span className="stat-foot">From completed workouts this week</span>
        </article>
        <article className="stat-card">
          <span>Calories today</span>
          <div className="stat-value">
            {number(data.macros.calories)}
            <small>kcal</small>
          </div>
          <div className="meter">
            <span style={{ width: calorieProgress + '%' }} />
          </div>
          <small>Personal target: {number(user.goals.dailyCalories)} kcal</small>
        </article>
        <article className="stat-card">
          <span>Body weight</span>
          <div className="stat-value">
            {data.latestWeight == null
              ? '—'
              : number(displayValue(data.latestWeight, 'weight', user.settings.units))}
            <small>{unit('weight', user.settings.units)}</small>
          </div>
          <Badge tone={data.weightStatus.tone}>{data.weightStatus.label}</Badge>
        </article>
      </section>
      <div className="dashboard-columns">
        <section className="card">
          <div className="card-head">
            <div>
              <span className="eyebrow">KEEP SHOWING UP</span>
              <h2>Your weekly activity</h2>
            </div>
            <Badge tone={data.weekCount >= user.goals.weeklyWorkouts ? 'success' : 'neutral'}>
              This week
            </Badge>
          </div>
          <ActivityChart data={data.activity} />
          <div className="card-bottom">
            <strong>{data.weekCount} sessions completed</strong>
            <Link to="/workouts">View workouts →</Link>
          </div>
        </section>
        <section className="focus-card">
          <span className="eyebrow">YOUR NEXT SMALL WIN</span>
          <h2>
            Make time <br />
            for yourself.
          </h2>
          <p>A short session is still a step forward. Start with what feels right today.</p>
          <Link className="button dark" to="/workouts?new=1">
            Log a workout <span>→</span>
          </Link>
          <div className="focus-art" aria-hidden="true">
            <span />
            <span />
            <span />
          </div>
        </section>
      </div>
      <div className="dashboard-columns">
        <section className="card">
          <div className="card-head">
            <div>
              <span className="eyebrow">THE BIGGER PICTURE</span>
              <h2>Weight trend</h2>
            </div>
            <Link to="/progress">View progress →</Link>
          </div>
          <TrendChart
            data={weightData}
            label={'Weight (' + unit('weight', user.settings.units) + ')'}
            target={
              user.goals.targetWeight == null
                ? null
                : displayValue(user.goals.targetWeight, 'weight', user.settings.units)
            }
            height={220}
          />
          <p className="card-note">
            Last 30 days · Your target is personal, not a medical assessment.
          </p>
        </section>
        <section className="card">
          <div className="card-head">
            <div>
              <span className="eyebrow">FUEL YOUR DAY</span>
              <h2>Today’s nutrition</h2>
            </div>
            <Link to="/meals?new=1">+ Log meal</Link>
          </div>
          <div className="nutrition-total">
            <strong>{number(data.macros.calories)}</strong>
            <span>/ {number(user.goals.dailyCalories)} kcal</span>
          </div>
          <div className="macro-row">
            {[
              ['protein', 'Protein'],
              ['carbs', 'Carbs'],
              ['fat', 'Fat']
            ].map(([key, label], index) => (
              <div key={key}>
                <span className={'macro-line macro-' + index} />
                <strong>
                  {number(data.macros[key])}
                  <small> g</small>
                </strong>
                <span>{label}</span>
              </div>
            ))}
          </div>
          {data.mealsToday.length ? (
            <div className="mini-meals">
              {data.mealsToday.slice(0, 3).map((meal) => (
                <div key={meal._id}>
                  <span className="capitalize">{meal.mealType}</span>
                  <strong>{number(meal.calories)} kcal</strong>
                </div>
              ))}
            </div>
          ) : (
            <p className="card-note">No meals logged today. Your next meal is a fresh start.</p>
          )}
        </section>
      </div>
      <section className="card">
        <div className="card-head">
          <div>
            <span className="eyebrow">YOUR RECENT SESSIONS</span>
            <h2>Keep your momentum</h2>
          </div>
          <Link to="/workouts">View all →</Link>
        </div>
        {data.recent.length ? (
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>Workout</th>
                  <th>Date</th>
                  <th>Duration</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {data.recent.map((item) => (
                  <tr key={item._id}>
                    <td>
                      <strong>{item.title}</strong>
                      <small className="table-sub capitalize">{item.category}</small>
                    </td>
                    <td>{dateLabel(item.date)}</td>
                    <td>{item.duration} min</td>
                    <td>
                      <Badge tone={item.status === 'completed' ? 'success' : 'warning'}>
                        {item.status === 'completed' ? 'Completed' : 'Planned'}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <Empty title="Your first workout belongs here">
            Log a session or build a routine in Workouts.
          </Empty>
        )}
      </section>
    </>
  );
}
