import { useState } from 'react';
import { useData } from '../../hooks/useData';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { api } from '../../lib/api';
import {
  Button,
  Field,
  Select,
  Check,
  Badge,
  Actions,
  Empty,
  Loading,
  ErrorMessage
} from '../../components/UI';
import Modal, { Confirm } from '../../components/Modal';
const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
function ReminderForm({ item, onSaved, onClose }) {
  const [form, setForm] = useState(
      item || {
        title: '',
        type: 'workout',
        time: '18:00',
        days: [1, 3, 5],
        enabled: true,
        email: false
      }
    ),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await api('/reminders' + (item ? '/' + item._id : ''), {
        method: item ? 'PUT' : 'POST',
        body: form
      });
      onSaved();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <form className="form-stack" onSubmit={submit}>
      <Field
        label="Reminder name"
        required
        maxLength={100}
        value={form.title}
        onChange={(e) => set('title', e.target.value)}
        placeholder="Time for your workout"
      />
      <div className="form-grid">
        <Select label="Type" value={form.type} onChange={(e) => set('type', e.target.value)}>
          <option value="workout">Workout</option>
          <option value="meal">Meal</option>
          <option value="goal">Goal check-in</option>
        </Select>
        <Field
          label="Time"
          type="time"
          required
          value={form.time}
          onChange={(e) => set('time', e.target.value)}
        />
      </div>
      <fieldset className="days">
        <legend>Repeat on</legend>
        {days.map((day, index) => (
          <label key={day} className={form.days.includes(index) ? 'selected' : ''}>
            <input
              type="checkbox"
              checked={form.days.includes(index)}
              onChange={(e) =>
                set(
                  'days',
                  e.target.checked ? [...form.days, index] : form.days.filter((d) => d !== index)
                )
              }
            />
            {day}
          </label>
        ))}
      </fieldset>
      <Check checked={form.enabled} onChange={(e) => set('enabled', e.target.checked)}>
        Reminder enabled
      </Check>
      <Check checked={form.email} onChange={(e) => set('email', e.target.checked)}>
        Also send by email when email reminders are enabled
      </Check>
      <ErrorMessage message={error} />
      <div className="form-footer">
        <Button type="button" tone="quiet" onClick={onClose}>
          Cancel
        </Button>
        <Button busy={busy} type="submit">
          Save reminder
        </Button>
      </div>
    </form>
  );
}
export default function Reminders() {
  const { user } = useAuth(),
    toast = useToast(),
    { data, loading, error, reload } = useData('/reminders');
  const [editing, setEditing] = useState(null),
    [deleting, setDeleting] = useState(null),
    [busy, setBusy] = useState(false);
  async function remove() {
    setBusy(true);
    try {
      await api('/reminders/' + deleting._id, { method: 'DELETE' });
      setDeleting(null);
      reload();
      toast('Reminder deleted.');
    } catch (e) {
      toast(e.message, 'danger');
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <section className="card">
        <div className="card-head">
          <h2>Your reminders</h2>
          <Button onClick={() => setEditing({})}>+ Add reminder</Button>
        </div>
        <p className="muted small">
          Timezone: {user.settings.timezone}. Reminders are checked while the app server is running.
          Missed reminders from today arrive when it restarts; older days are not replayed.
        </p>
        <ErrorMessage message={error} retry={reload} />
        {loading ? (
          <Loading />
        ) : data?.items.length ? (
          <div className="reminder-list">
            {data.items.map((item) => (
              <article key={item._id}>
                <div>
                  <strong>{item.title}</strong>
                  <p>
                    {item.time} · {item.days.map((d) => days[d]).join(', ')}
                  </p>
                  <Badge tone={item.enabled ? 'success' : 'neutral'}>
                    {item.enabled ? 'Active' : 'Paused'}
                  </Badge>
                  {item.email && <span className="small muted"> · Email requested</span>}
                </div>
                <Actions onEdit={() => setEditing(item)} onDelete={() => setDeleting(item)} />
              </article>
            ))}
          </div>
        ) : (
          <Empty title="A gentle nudge helps">Schedule workouts, meals and goal check-ins.</Empty>
        )}
      </section>
      {editing && (
        <Modal
          title={editing._id ? 'Edit reminder' : 'Create a reminder'}
          onClose={() => setEditing(null)}
        >
          <ReminderForm
            item={editing._id ? editing : null}
            onClose={() => setEditing(null)}
            onSaved={() => {
              setEditing(null);
              reload();
              toast('Reminder saved.');
            }}
          />
        </Modal>
      )}
      {deleting && (
        <Confirm
          title="Delete this reminder?"
          busy={busy}
          onConfirm={remove}
          onCancel={() => setDeleting(null)}
        >
          {deleting.title} will be removed.
        </Confirm>
      )}
    </>
  );
}
