import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { api } from '../../lib/api';
import { Button, Field, Check, Badge, ErrorMessage } from '../../components/UI';
import Modal from '../../components/Modal';
export default function AccountSettings() {
  const { user, setUser, refresh, services } = useAuth(),
    toast = useToast(),
    navigate = useNavigate();
  const [form, setForm] = useState({
      name: user.name,
      username: user.username,
      email: user.email,
      currentPassword: '',
      discoverable: user.discoverable
    }),
    [busy, setBusy] = useState(''),
    [error, setError] = useState(''),
    [deleting, setDeleting] = useState(false);
  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));
  async function profile(e) {
    e.preventDefault();
    setBusy('profile');
    setError('');
    try {
      const data = await api('/users/me', { method: 'PATCH', body: form });
      setUser(data.user);
      set('currentPassword', '');
      toast(data.message);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy('');
    }
  }
  async function password(e) {
    e.preventDefault();
    const element = e.currentTarget,
      values = Object.fromEntries(new FormData(element));
    if (values.newPassword !== values.confirmPassword)
      return toast('Passwords do not match.', 'danger');
    setBusy('password');
    try {
      const data = await api('/users/me/password', { method: 'PATCH', body: values });
      element.reset();
      toast(data.message);
    } catch (err) {
      toast(err.message, 'danger');
    } finally {
      setBusy('');
    }
  }
  async function photo(e) {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast('Choose a photo smaller than 5 MB.', 'danger');
      return;
    }
    setBusy('photo');
    const body = new FormData();
    body.append('avatar', file);
    try {
      const data = await api('/users/me/avatar', { method: 'POST', body });
      setUser(data.user);
      toast(data.message);
    } catch (err) {
      toast(err.message, 'danger');
    } finally {
      setBusy('');
      e.target.value = '';
    }
  }
  async function removePhoto() {
    setBusy('photo');
    try {
      const data = await api('/users/me/avatar', { method: 'DELETE' });
      setUser(data.user);
      toast(data.message);
    } catch (e) {
      toast(e.message, 'danger');
    } finally {
      setBusy('');
    }
  }
  async function verify() {
    setBusy('verify');
    try {
      const data = await api('/auth/verification', { method: 'POST' });
      toast(data.message);
    } catch (err) {
      toast(err.message, 'danger');
    } finally {
      setBusy('');
    }
  }
  async function remove(e) {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(e.currentTarget));
    setBusy('delete');
    try {
      await api('/users/me', { method: 'DELETE', body });
      setUser(null);
      await refresh();
      navigate('/register');
      toast('Your account and records have been deleted.');
    } catch (err) {
      toast(err.message, 'danger');
    } finally {
      setBusy('');
    }
  }
  return (
    <>
      <section className="card">
        <div className="card-head">
          <h2>My profile</h2>
          <Badge tone="success">Private records</Badge>
        </div>
        <div className="photo-settings">
          {user.avatarUrl ? (
            <img className="avatar large" src={user.avatarUrl} alt="Your profile" />
          ) : (
            <span className="avatar initials large">{user.name[0]}</span>
          )}
          <div>
            <label
              className={
                'button quiet file-button ' +
                (!services.media || busy === 'photo' ? 'disabled' : '')
              }
            >
              {busy === 'photo' ? 'Uploading…' : 'Change photo'}
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={photo}
                disabled={!services.media || busy === 'photo'}
              />
            </label>
            {user.avatarUrl && (
              <button
                className="text-button danger"
                onClick={removePhoto}
                disabled={busy === 'photo'}
              >
                Remove
              </button>
            )}
            <p className="small muted">
              JPG, PNG or WebP · Maximum 5 MB
              {!services.media && ' · Uploads are not configured yet.'}
            </p>
          </div>
        </div>
        <form className="form-stack" onSubmit={profile}>
          <div className="form-grid">
            <Field
              label="Full name"
              required
              maxLength={80}
              autoComplete="name"
              value={form.name}
              onChange={(e) => set('name', e.target.value)}
            />
            <Field
              label="Username"
              required
              pattern="[a-zA-Z0-9_.]{3,30}"
              autoComplete="username"
              value={form.username}
              onChange={(e) => set('username', e.target.value)}
            />
          </div>
          <Field
            label="Email address"
            type="email"
            required
            autoComplete="email"
            value={form.email}
            onChange={(e) => set('email', e.target.value)}
          />
          {form.email !== user.email && (
            <Field
              label="Current password to change email"
              type="password"
              autoComplete="current-password"
              required
              value={form.currentPassword}
              onChange={(e) => set('currentPassword', e.target.value)}
            />
          )}
          <div className="inline-details">
            <Badge tone={user.emailVerifiedAt ? 'success' : 'warning'}>
              {user.emailVerifiedAt ? 'Email verified' : 'Email not verified'}
            </Badge>
            {!user.emailVerifiedAt && (
              <button
                type="button"
                className="text-button"
                disabled={busy === 'verify' || !services.email}
                onClick={verify}
              >
                {busy === 'verify' ? 'Sending…' : 'Send verification email'}
              </button>
            )}
          </div>
          <div className="preference-box">
            <Check
              checked={form.discoverable}
              onChange={(e) => set('discoverable', e.target.checked)}
            >
              Make my name, username and photo visible in the optional community.
            </Check>
            <p className="small muted">
              Off by default. Your workouts, meals, measurements and email always stay private.
              Turning this off also hides your community posts and replies.
            </p>
          </div>
          <ErrorMessage message={error} />
          <div className="form-footer">
            <Button type="submit" busy={busy === 'profile'}>
              Save profile
            </Button>
          </div>
        </form>
      </section>
      <section className="card">
        <h2>Change password</h2>
        <p className="muted">Use at least 10 characters. Other sessions will be signed out.</p>
        <form className="form-stack" onSubmit={password}>
          <Field
            label="Current password"
            type="password"
            name="currentPassword"
            autoComplete="current-password"
            required
          />
          <div className="form-grid">
            <Field
              label="New password"
              type="password"
              name="newPassword"
              autoComplete="new-password"
              minLength={10}
              maxLength={128}
              required
            />
            <Field
              label="Confirm new password"
              type="password"
              name="confirmPassword"
              autoComplete="new-password"
              minLength={10}
              required
            />
          </div>
          <div className="form-footer">
            <Button type="submit" busy={busy === 'password'}>
              Update password
            </Button>
          </div>
        </form>
      </section>
      <section className="card danger-zone">
        <h2>Delete account</h2>
        <p>
          Delete your account and its personal records permanently. Export a report first if you
          want to keep a copy.
        </p>
        <Button tone="danger" onClick={() => setDeleting(true)}>
          Delete my account
        </Button>
      </section>
      {deleting && (
        <Modal title="Permanently delete your account?" onClose={() => setDeleting(false)}>
          <p>
            Your profile, workouts, meals, progress, reminders and community content will be
            removed.
          </p>
          <form onSubmit={remove} className="form-stack">
            <Field
              label="Confirm your password"
              type="password"
              name="password"
              autoComplete="current-password"
              required
            />
            <div className="form-footer">
              <Button type="button" tone="quiet" onClick={() => setDeleting(false)}>
                Cancel
              </Button>
              <Button type="submit" tone="danger" busy={busy === 'delete'}>
                Delete everything
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </>
  );
}
