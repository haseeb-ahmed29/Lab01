import { Link } from 'react-router-dom';
import { useData } from '../hooks/useData';
import { useToast } from '../context/ToastContext';
import { api } from '../lib/api';
import { PageTitle, Button, Badge, Empty, Loading, ErrorMessage } from '../components/UI';
export default function Notifications() {
  const { data, loading, error, reload } = useData('/notifications'),
    toast = useToast();
  async function read(id) {
    try {
      await api('/notifications/' + (id ? id + '/read' : 'read-all'), { method: 'PATCH' });
      reload();
    } catch (e) {
      toast(e.message, 'danger');
    }
  }
  return (
    <>
      <PageTitle
        eyebrow="YOUR LATEST UPDATES"
        title="Notifications"
        description="A little encouragement and a timely reminder."
      >
        <Button tone="quiet" onClick={() => read()} disabled={!data?.unread}>
          Mark all as read
        </Button>
      </PageTitle>
      <section className="card">
        <ErrorMessage message={error} retry={reload} />
        {loading ? (
          <Loading />
        ) : data?.items.length ? (
          <div className="notification-list">
            {data.items.map((item) => (
              <article key={item._id} className={item.read ? '' : 'unread'}>
                <div>
                  <h3>
                    {item.title} {!item.read && <Badge>New</Badge>}
                  </h3>
                  <p>{item.message}</p>
                  <small className="muted">{new Date(item.createdAt).toLocaleString()}</small>
                </div>
                <div className="row-actions">
                  <Link to={item.link} onClick={() => read(item._id)}>
                    Open
                  </Link>
                  {!item.read && (
                    <button className="text-button" onClick={() => read(item._id)}>
                      Mark read
                    </button>
                  )}
                </div>
              </article>
            ))}
          </div>
        ) : (
          <Empty title="You are all caught up">
            Workout completions, goals and reminders will appear here.
          </Empty>
        )}
        <p className="small muted">Latest 50 notifications.</p>
      </section>
    </>
  );
}
