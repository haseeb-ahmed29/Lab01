import dotenv from 'dotenv';
import { fileURLToPath } from 'node:url';

dotenv.config({ path: fileURLToPath(new URL('../../.env', import.meta.url)), quiet: true });

export function getConfig(overrides = {}) {
  const config = {
    nodeEnv: process.env.NODE_ENV || 'development',
    port: Number(process.env.PORT || 5000),
    clientUrl: process.env.CLIENT_URL || 'http://localhost:5173',
    mongoUri: process.env.MONGODB_URI || '',
    sessionSecret: process.env.SESSION_SECRET || '',
    cloudinary: {
      cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
      api_key: process.env.CLOUDINARY_API_KEY,
      api_secret: process.env.CLOUDINARY_API_SECRET
    },
    smtp: {
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: process.env.SMTP_SECURE === 'true',
      requireTLS: process.env.SMTP_REQUIRE_TLS !== 'false',
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
      from: process.env.SMTP_FROM,
      supportEmail: process.env.SUPPORT_EMAIL
    },
    ...overrides
  };
  if (!config.mongoUri || config.mongoUri.includes('YOUR_')) {
    throw new Error('Add your MongoDB Atlas connection string to backend/.env MONGODB_URI.');
  }
  if (config.sessionSecret.length < 32) {
    throw new Error(
      'Set SESSION_SECRET in backend/.env to a random value of at least 32 characters.'
    );
  }
  new URL(config.clientUrl);
  return config;
}
