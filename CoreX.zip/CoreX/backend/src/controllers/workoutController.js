import Workout from '../models/Workout.js';
import { dateFilter, literalRegex, pagination } from '../utils/dates.js';
import { requireResult } from '../utils/errors.js';
import { workoutNotifications } from '../services/notifications.js';

export async function listWorkouts(req, res) {
  const query = req.filters;
  const filter = { userId: req.user._id, ...dateFilter(query) };
  for (const key of ['kind', 'category', 'status']) if (query[key]) filter[key] = query[key];
  if (query.q)
    filter.$or = ['title', 'tags', 'exercises.name'].map((key) => ({
      [key]: { $regex: literalRegex(query.q), $options: 'i' }
    }));
  const { page, limit, skip } = pagination(query);
  const [items, total] = await Promise.all([
    Workout.find(filter).sort({ date: -1, createdAt: -1 }).skip(skip).limit(limit),
    Workout.countDocuments(filter)
  ]);
  res.json({ items, total, page, pages: Math.max(1, Math.ceil(total / limit)) });
}
export async function createWorkout(req, res) {
  const workout = await Workout.create({ ...req.body, userId: req.user._id });
  await workoutNotifications(req.user, workout, false);
  res.status(201).json({ item: workout, message: 'Workout saved.' });
}
export async function updateWorkout(req, res) {
  const previous = requireResult(
    await Workout.findOneAndUpdate({ _id: req.params.id, userId: req.user._id }, req.body)
  );
  const item = await Workout.findOne({ _id: req.params.id, userId: req.user._id });
  await workoutNotifications(
    req.user,
    item,
    previous.kind === 'session' && previous.status === 'completed'
  );
  res.json({ item, message: 'Workout updated.' });
}
export async function deleteWorkout(req, res) {
  requireResult(await Workout.findOneAndDelete({ _id: req.params.id, userId: req.user._id }));
  res.json({ message: 'Workout deleted.' });
}
