import User from '../models/User.js';
import { Follow, Post, Reply } from '../models/Community.js';
import { ApiError, requireResult } from '../utils/errors.js';
import { literalRegex, pagination } from '../utils/dates.js';
import { notify } from '../services/notifications.js';

function publicProfile(user) {
  return {
    _id: user._id,
    name: user.name,
    username: user.username,
    avatarUrl: user.avatar?.publicId
      ? '/api/users/' + user._id + '/avatar?v=' + user.avatar.version
      : ''
  };
}
function optIn(req) {
  if (!req.user.discoverable)
    throw new ApiError(
      403,
      'Enable community visibility in your profile before joining. Your fitness records stay private.'
    );
}
export async function searchPeople(req, res) {
  const { skip, limit, page } = pagination(req.filters);
  const query = { discoverable: true, _id: { $ne: req.user._id } };
  if (req.filters.q)
    query.$or = [
      { name: { $regex: literalRegex(req.filters.q), $options: 'i' } },
      { username: { $regex: literalRegex(req.filters.q), $options: 'i' } }
    ];
  const [users, total, follows] = await Promise.all([
    User.find(query)
      .select('name username avatar')
      .sort({ name: 1 })
      .skip(skip)
      .limit(limit)
      .lean(),
    User.countDocuments(query),
    Follow.find({ follower: req.user._id }).select('following').lean()
  ]);
  const following = new Set(follows.map((item) => item.following.toString()));
  res.json({
    items: users.map((user) => ({
      ...publicProfile(user),
      following: following.has(user._id.toString())
    })),
    page,
    total,
    limit
  });
}
export async function followPerson(req, res) {
  optIn(req);
  if (req.params.id === req.user.id) throw new ApiError(400, 'You cannot follow yourself.');
  const user = requireResult(
    await User.findOne({ _id: req.params.id, discoverable: true }),
    'Profile not found.'
  );
  const result = await Follow.updateOne(
    { follower: req.user._id, following: user._id },
    {},
    { upsert: true }
  );
  if (result.upsertedCount)
    await notify(
      user,
      'follow',
      'A new connection',
      req.user.name + ' is following you.',
      '/settings?tab=community',
      'follow:' + req.user.id + ':' + user.id
    );
  res.json({ message: 'Following. Personal fitness data stays private.' });
}
export async function unfollowPerson(req, res) {
  await Follow.deleteOne({ follower: req.user._id, following: req.params.id });
  res.json({ message: 'Unfollowed.' });
}
export async function listPosts(req, res) {
  const { skip, limit, page } = pagination(req.filters);
  const visibleUsers = await User.find({ discoverable: true }).select('_id');
  const query = { userId: { $in: visibleUsers.map((user) => user._id) } };
  if (req.filters.q) query.title = { $regex: literalRegex(req.filters.q), $options: 'i' };
  const [posts, total] = await Promise.all([
    Post.find(query)
      .populate('userId', 'name username avatar')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .lean(),
    Post.countDocuments(query)
  ]);
  const items = await Promise.all(
    posts.map(async (post) => {
      const replies = await Reply.find({ postId: post._id, userId: query.userId })
        .populate('userId', 'name username avatar')
        .sort({ createdAt: -1 })
        .limit(30)
        .lean();
      return {
        ...post,
        userId: undefined,
        author: publicProfile(post.userId),
        replies: replies
          .reverse()
          .map((reply) => ({ ...reply, userId: undefined, author: publicProfile(reply.userId) }))
      };
    })
  );
  res.json({ items, total, page, limit });
}
export async function createPost(req, res) {
  optIn(req);
  res.status(201).json({ item: await Post.create({ ...req.body, userId: req.user._id }) });
}
export async function deletePost(req, res) {
  requireResult(await Post.findOneAndDelete({ _id: req.params.id, userId: req.user._id }));
  await Reply.deleteMany({ postId: req.params.id });
  res.json({ message: 'Post deleted.' });
}
export async function createReply(req, res) {
  optIn(req);
  const post = requireResult(await Post.findById(req.params.id));
  const author = requireResult(await User.findOne({ _id: post.userId, discoverable: true }));
  const reply = await Reply.create({ ...req.body, postId: post._id, userId: req.user._id });
  if (author.id !== req.user.id)
    await notify(
      author,
      'forum',
      'New reply',
      req.user.name + ' replied to ' + post.title,
      '/settings?tab=community',
      'reply:' + reply.id
    );
  res.status(201).json({ item: reply });
}
export async function deleteReply(req, res) {
  requireResult(await Reply.findOneAndDelete({ _id: req.params.id, userId: req.user._id }));
  res.json({ message: 'Reply deleted.' });
}
