import Reminder from '../models/Reminder.js';
import Notification from '../models/Notification.js';
import SupportTicket from '../models/SupportTicket.js';
import { requireResult } from '../utils/errors.js';

export const listReminders = async (req, res) =>
  res.json({ items: await Reminder.find({ userId: req.user._id }).sort({ time: 1 }) });
export const createReminder = async (req, res) =>
  res.status(201).json({ item: await Reminder.create({ ...req.body, userId: req.user._id }) });
export const updateReminder = async (req, res) =>
  res.json({
    item: requireResult(
      await Reminder.findOneAndUpdate(
        { _id: req.params.id, userId: req.user._id },
        { ...req.body, $unset: { lastSentDate: '' } },
        { new: true }
      )
    )
  });
export const deleteReminder = async (req, res) => {
  requireResult(await Reminder.findOneAndDelete({ _id: req.params.id, userId: req.user._id }));
  res.json({ message: 'Reminder deleted.' });
};
export const listNotifications = async (req, res) => {
  const [items, unread] = await Promise.all([
    Notification.find({ userId: req.user._id }).sort({ createdAt: -1 }).limit(50),
    Notification.countDocuments({ userId: req.user._id, read: false })
  ]);
  res.json({ items, unread });
};
export const markNotification = async (req, res) => {
  requireResult(
    await Notification.findOneAndUpdate(
      { _id: req.params.id, userId: req.user._id },
      { read: true }
    )
  );
  res.json({ message: 'Marked as read.' });
};
export const markAllNotifications = async (req, res) => {
  await Notification.updateMany({ userId: req.user._id, read: false }, { read: true });
  res.json({ message: 'All marked as read.' });
};
export function supportController({ email, config }) {
  return async (req, res) => {
    const ticket = await SupportTicket.create({ ...req.body, userId: req.user._id });
    if (
      email.enabled &&
      config.smtp.supportEmail &&
      !config.smtp.supportEmail.includes('example.com')
    ) {
      try {
        await email.send(
          config.smtp.supportEmail,
          'CoreX support: ' + ticket.subject,
          'Ticket: ' +
            ticket.id +
            '\nFrom: ' +
            req.user.email +
            '\nTopic: ' +
            ticket.topic +
            '\n\n' +
            ticket.message
        );
        ticket.emailSent = true;
        await ticket.save();
      } catch {
        console.error('Support email delivery failed; ticket remains saved.');
      }
    }
    res
      .status(201)
      .json({
        message: ticket.emailSent
          ? 'Your message has been sent to support.'
          : 'Your message is saved. Email delivery is not available yet.',
        ticketId: ticket.id,
        emailSent: ticket.emailSent
      });
  };
}
