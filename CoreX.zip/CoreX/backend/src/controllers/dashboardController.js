import Workout from '../models/Workout.js';
import Meal from '../models/Meal.js';
import Progress from '../models/Progress.js';
import { addDays, weekStart, localDate, dayRange } from '../utils/dates.js';
import { ApiError } from '../utils/errors.js';

export function weightStatus(entries, target) {
  if (!entries.length || target == null)
    return { tone: 'neutral', label: 'Set your personal goal' };
  const current = entries[entries.length - 1].value;
  if (Math.abs(current - target) <= 0.2) return { tone: 'success', label: 'At your target' };
  if (entries.length < 2) return { tone: 'neutral', label: 'First entry recorded' };
  const previous = entries[entries.length - 2].value;
  const change = Math.abs(previous - target) - Math.abs(current - target);
  if (change > 0.05) return { tone: 'success', label: 'Closer to your goal' };
  if (change < -0.05) return { tone: 'danger', label: 'Further from your goal' };
  return { tone: 'warning', label: 'Holding steady' };
}
export async function dashboard(req, res) {
  const today = localDate(req.user.settings.timezone);
  const start = weekStart(today);
  const from = req.filters.from || addDays(today, -29);
  const to = req.filters.to || today;
  if (from > to || (new Date(to) - new Date(from)) / 86400000 > 365)
    throw new ApiError(400, 'Choose a dashboard range of up to 366 days.');
  const owner = { userId: req.user._id };
  const [week, mealsToday, workouts, meals, progress, recent, lastWeights] = await Promise.all([
    Workout.find({
      ...owner,
      kind: 'session',
      status: 'completed',
      date: { $gte: start, $lte: addDays(start, 6) }
    }).lean(),
    Meal.find({ ...owner, date: today })
      .sort({ createdAt: -1 })
      .lean(),
    Workout.find({ ...owner, kind: 'session', status: 'completed', date: { $gte: from, $lte: to } })
      .sort({ date: 1 })
      .lean(),
    Meal.find({ ...owner, date: { $gte: from, $lte: to } })
      .sort({ date: 1 })
      .lean(),
    Progress.find({ ...owner, date: { $gte: from, $lte: to } })
      .sort({ date: 1, createdAt: 1 })
      .lean(),
    Workout.find({ ...owner, kind: 'session' })
      .sort({ date: -1, createdAt: -1 })
      .limit(4)
      .lean(),
    Progress.find({ ...owner, metric: 'weight' })
      .sort({ date: -1, createdAt: -1 })
      .limit(2)
      .lean()
  ]);
  const macros = ['calories', 'protein', 'carbs', 'fat'].reduce(
    (values, key) => ({ ...values, [key]: mealsToday.reduce((sum, meal) => sum + meal[key], 0) }),
    {}
  );
  res.json({
    today,
    from,
    to,
    weekCount: week.length,
    weekDuration: week.reduce((sum, item) => sum + item.duration, 0),
    latestWeight: lastWeights[0]?.value ?? null,
    weightStatus: weightStatus([...lastWeights].reverse(), req.user.goals.targetWeight),
    macros,
    mealsToday,
    recent,
    workouts,
    progress,
    activity: dayRange(start, addDays(start, 6)).map((date) => ({
      date,
      count: week.filter((workout) => workout.date === date).length
    })),
    calories: dayRange(from, to)
      .slice(-366)
      .map((date) => ({
        date,
        calories: meals
          .filter((meal) => meal.date === date)
          .reduce((sum, meal) => sum + meal.calories, 0)
      }))
  });
}
