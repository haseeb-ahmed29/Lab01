import User from '../models/User.js';
import AuthToken from '../models/AuthToken.js';
import { ApiError } from '../utils/errors.js';
import { hashPassword, verifyPassword, randomToken, tokenHash } from '../utils/password.js';

export function publicUser(user) {
  const data = user.toObject ? user.toObject() : { ...user };
  delete data.passwordHash;
  delete data.sessionVersion;
  delete data.__v;
  data.avatarUrl = data.avatar?.publicId
    ? '/api/users/' + data._id + '/avatar?v=' + data.avatar.version
    : '';
  delete data.avatar;
  return data;
}

async function signInSession(req, user) {
  await new Promise((resolve, reject) =>
    req.session.regenerate((error) => (error ? reject(error) : resolve()))
  );
  req.session.userId = user._id.toString();
  req.session.version = user.sessionVersion;
  req.session.csrfToken = randomToken();
  await new Promise((resolve, reject) =>
    req.session.save((error) => (error ? reject(error) : resolve()))
  );
}

export function authController({ config, email }) {
  async function issueToken(user, purpose) {
    const token = randomToken();
    await AuthToken.findOneAndUpdate(
      { userId: user._id, purpose },
      {
        digest: tokenHash(token),
        expiresAt: new Date(Date.now() + (purpose === 'reset' ? 30 : 1440) * 60000),
        sessionVersion: user.sessionVersion,
        email: user.email
      },
      { upsert: true }
    );
    return token;
  }
  return {
    session: async (req, res) => {
      if (!req.session.csrfToken) req.session.csrfToken = randomToken();
      let user = req.session.userId ? await User.findById(req.session.userId) : null;
      if (user?.sessionVersion !== req.session.version) user = null;
      res.json({
        user: user ? publicUser(user) : null,
        csrfToken: req.session.csrfToken,
        services: {
          email: email.enabled,
          media: Boolean(
            config.cloudinary.cloud_name &&
              config.cloudinary.api_key &&
              config.cloudinary.api_secret
          )
        }
      });
    },
    register: async (req, res) => {
      const { name, username, password, email: address } = req.body;
      const user = await User.create({
        name,
        username,
        email: address,
        passwordHash: await hashPassword(password),
        consentAt: new Date()
      });
      await signInSession(req, user);
      if (email.enabled) {
        email
          .send(
            user.email,
            'Welcome to CoreX',
            'Welcome, ' + user.name + '.\nYour personal tracker is ready.\n' + config.clientUrl
          )
          .catch(() => console.error('Welcome email could not be delivered.'));
      }
      res.status(201).json({ user: publicUser(user), csrfToken: req.session.csrfToken });
    },
    login: async (req, res) => {
      const identifier = req.body.identifier.trim().toLowerCase();
      const user = await User.findOne({
        $or: [{ email: identifier }, { username: identifier }]
      }).select('+passwordHash');
      if (!user || !(await verifyPassword(req.body.password, user.passwordHash)))
        throw new ApiError(401, 'Email, username or password is incorrect.');
      await signInSession(req, user);
      res.json({ user: publicUser(user), csrfToken: req.session.csrfToken });
    },
    logout: async (req, res) => {
      await new Promise((resolve, reject) =>
        req.session.destroy((error) => (error ? reject(error) : resolve()))
      );
      res.clearCookie('corex.sid', {
        path: '/',
        httpOnly: true,
        sameSite: 'lax',
        secure: config.nodeEnv === 'production'
      });
      res.json({ message: 'Signed out.' });
    },
    forgot: async (req, res) => {
      email.requireConfigured();
      const user = await User.findOne({ email: req.body.email });
      if (user) {
        const token = await issueToken(user, 'reset');
        try {
          await email.send(
            user.email,
            'Reset your CoreX password',
            'Open this link within 30 minutes to choose a new password.\n\n' +
              config.clientUrl +
              '/reset-password?token=' +
              token +
              '\n\nIf you did not request this, you can ignore this email.'
          );
        } catch {
          console.error('Password reset email could not be delivered.');
        }
      }
      res.json({ message: 'If an account matches that email, a reset link has been sent.' });
    },
    reset: async (req, res) => {
      const passwordHash = await hashPassword(req.body.password);
      const token = await AuthToken.findOneAndDelete({
        digest: tokenHash(req.body.token),
        purpose: 'reset',
        expiresAt: { $gt: new Date() }
      });
      if (!token)
        throw new ApiError(400, 'This reset link is invalid or expired. Request a new one.');
      const user = await User.findOneAndUpdate(
        { _id: token.userId, sessionVersion: token.sessionVersion, email: token.email },
        { $set: { passwordHash }, $inc: { sessionVersion: 1 } }
      );
      if (!user) throw new ApiError(400, 'This reset link is no longer valid.');
      res.json({ message: 'Password updated. Sign in with your new password.' });
    },
    requestVerification: async (req, res) => {
      email.requireConfigured();
      if (req.user.emailVerifiedAt) return res.json({ message: 'Your email is already verified.' });
      const token = await issueToken(req.user, 'verify');
      await email.send(
        req.user.email,
        'Verify your CoreX email',
        'Verify your email within 24 hours.\n\n' + config.clientUrl + '/verify-email?token=' + token
      );
      res.json({ message: 'Verification email sent.' });
    },
    verifyEmail: async (req, res) => {
      const token = await AuthToken.findOneAndDelete({
        digest: tokenHash(req.body.token),
        purpose: 'verify',
        expiresAt: { $gt: new Date() }
      });
      if (!token) throw new ApiError(400, 'This verification link is invalid or expired.');
      const user = await User.findOneAndUpdate(
        { _id: token.userId, email: token.email },
        { emailVerifiedAt: new Date() }
      );
      if (!user) throw new ApiError(400, 'This verification link is no longer valid.');
      res.json({ message: 'Email verified. You can enable email reminders in Settings.' });
    }
  };
}
