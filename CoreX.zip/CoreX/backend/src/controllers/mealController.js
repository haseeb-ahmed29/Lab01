import Meal from '../models/Meal.js';
import { dateFilter, literalRegex, pagination } from '../utils/dates.js';
import { requireResult } from '../utils/errors.js';

function totals(foods) {
  return Object.fromEntries(
    ['calories', 'protein', 'carbs', 'fat'].map((key) => [
      key,
      Math.round(foods.reduce((sum, food) => sum + food[key], 0) * 100) / 100
    ])
  );
}
export async function listMeals(req, res) {
  const query = req.filters;
  const filter = { userId: req.user._id, ...dateFilter(query) };
  if (query.mealType) filter.mealType = query.mealType;
  if (query.q) filter['foods.name'] = { $regex: literalRegex(query.q), $options: 'i' };
  const { page, limit, skip } = pagination(query);
  const [items, total] = await Promise.all([
    Meal.find(filter).sort({ date: -1, createdAt: -1 }).skip(skip).limit(limit),
    Meal.countDocuments(filter)
  ]);
  res.json({ items, total, page, pages: Math.max(1, Math.ceil(total / limit)) });
}
export async function createMeal(req, res) {
  const item = await Meal.create({ ...req.body, ...totals(req.body.foods), userId: req.user._id });
  res.status(201).json({ item, message: 'Meal logged.' });
}
export async function updateMeal(req, res) {
  const item = requireResult(
    await Meal.findOneAndUpdate(
      { _id: req.params.id, userId: req.user._id },
      { ...req.body, ...totals(req.body.foods) },
      { new: true }
    )
  );
  res.json({ item, message: 'Meal updated.' });
}
export async function deleteMeal(req, res) {
  requireResult(await Meal.findOneAndDelete({ _id: req.params.id, userId: req.user._id }));
  res.json({ message: 'Meal deleted.' });
}
