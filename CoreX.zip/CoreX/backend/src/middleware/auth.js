import { timingSafeEqual } from 'node:crypto';
import User from '../models/User.js';
import { ApiError } from '../utils/errors.js';

export async function requireAuth(req, res, next) {
  if (!req.session.userId) throw new ApiError(401, 'Please sign in.');
  const user = await User.findById(req.session.userId);
  if (!user || user.sessionVersion !== req.session.version) {
    req.session.destroy(() => {});
    throw new ApiError(401, 'Your session has expired. Please sign in.');
  }
  req.user = user;
  next();
}

export function csrfProtection(clientUrl) {
  const allowedOrigin = new URL(clientUrl).origin;
  return (req, res, next) => {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
    if (req.headers.origin && req.headers.origin !== allowedOrigin)
      throw new ApiError(403, 'Request origin is not allowed.');
    const actual = Buffer.from(req.get('X-CSRF-Token') || '');
    const expected = Buffer.from(req.session.csrfToken || '');
    if (!actual.length || actual.length !== expected.length || !timingSafeEqual(actual, expected)) {
      throw new ApiError(403, 'Session protection expired. Refresh the page and retry.');
    }
    next();
  };
}
