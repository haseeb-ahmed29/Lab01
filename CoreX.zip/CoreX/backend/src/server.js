import mongoose from 'mongoose';
import { getConfig } from './config/env.js';
import { connectDatabase } from './config/database.js';
import { createApp } from './app.js';
import { startReminderWorker } from './services/reminders.js';

try {
  const config = getConfig();
  await connectDatabase(config.mongoUri);
  const { app, email, store } = createApp(config);
  // Wait for unique username/email and token indexes before accepting registrations.
  await Promise.all(Object.values(mongoose.models).map((model) => model.init()));
  const stopReminders = startReminderWorker(email);
  const server = app.listen(config.port, () =>
    console.log('CoreX API ready at http://localhost:' + config.port)
  );
  async function shutdown() {
    stopReminders();
    server.close(async () => {
      await store.close();
      await mongoose.disconnect();
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10000).unref();
  }
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
} catch (error) {
  console.error('CoreX could not start: ' + error.message);
  process.exit(1);
}
