import PDFDocument from 'pdfkit';
export function csvCell(value) {
  let text = value == null ? '' : String(value);
  // Prevent spreadsheet formula execution, including whitespace-prefixed formulas.
  if (/^[\s]*[=+@\-]/.test(text) || /^[\t\r\n]/.test(text)) text = "'" + text;
  return '"' + text.replaceAll('"', '""') + '"';
}
export function toCsv(rows) {
  return '\uFEFF' + rows.map((row) => row.map(csvCell).join(',')).join('\r\n');
}
export function sendPdf(res, rows, user, range) {
  const doc = new PDFDocument({ size: 'A4', margin: 42, bufferPages: true });
  res.type('application/pdf');
  doc.pipe(res);
  doc.fontSize(26).fillColor('#FB7359').text('CoreX');
  doc.fontSize(10).fillColor('#505763').text('FIT ZONE / PERSONAL ACTIVITY REPORT');
  doc.moveDown().fontSize(14).fillColor('#22242B').text(user.name);
  doc.fontSize(10).text(range).moveDown();
  doc
    .text('Recorded activity only. Goal colors describe progress toward your chosen targets.')
    .moveDown();
  rows.forEach((row, index) => {
    if (doc.y > 730) doc.addPage();
    doc
      .font(index === 0 ? 'Helvetica-Bold' : 'Helvetica')
      .fontSize(9)
      .fillColor('#22242B')
      .text(row.join('  |  '), { lineGap: 4 });
  });
  const rangePages = doc.bufferedPageRange();
  for (let page = 0; page < rangePages.count; page++) {
    doc.switchToPage(page);
    doc
      .fontSize(8)
      .fillColor('#707782')
      .text('CoreX • ' + (page + 1) + ' / ' + rangePages.count, 42, 795, { lineBreak: false });
  }
  doc.end();
}
