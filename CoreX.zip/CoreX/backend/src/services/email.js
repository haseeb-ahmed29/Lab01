import nodemailer from 'nodemailer';
import { ApiError } from '../utils/errors.js';

export function createEmailService(config) {
  const enabled = Boolean(config.host && config.from);
  const transport = enabled
    ? nodemailer.createTransport({
        host: config.host,
        port: config.port,
        secure: config.secure,
        requireTLS: config.requireTLS,
        auth: config.user ? { user: config.user, pass: config.pass } : undefined,
        connectionTimeout: 10000,
        greetingTimeout: 10000,
        socketTimeout: 15000
      })
    : null;
  return {
    enabled,
    requireConfigured() {
      if (!enabled)
        throw new ApiError(503, 'Email is not configured. Add SMTP credentials to backend/.env.');
    },
    async send(to, subject, text) {
      this.requireConfigured();
      await transport.sendMail({ from: config.from, to, subject, text });
    }
  };
}
