import { v2 as cloudinary } from 'cloudinary';
import sharp from 'sharp';
import { randomUUID } from 'node:crypto';
import { ApiError } from '../utils/errors.js';

export function createMediaService(config) {
  const enabled = Boolean(config.cloud_name && config.api_key && config.api_secret);
  cloudinary.config(config);
  return {
    enabled,
    async uploadAvatar(file, userId) {
      if (!enabled)
        throw new ApiError(
          503,
          'Add your Cloudinary credentials to backend/.env to upload profile photos.'
        );
      if (!file) throw new ApiError(400, 'Select a profile photo.');
      let buffer;
      try {
        const image = sharp(file.buffer, { limitInputPixels: 25000000 });
        const metadata = await image.metadata();
        if (!['jpeg', 'png', 'webp'].includes(metadata.format))
          throw new Error('Unsupported image');
        buffer = await image
          .rotate()
          .resize(400, 400, { fit: 'cover' })
          .webp({ quality: 85 })
          .toBuffer();
      } catch {
        throw new ApiError(400, 'Choose a valid JPG, PNG or WebP image, up to 25 megapixels.');
      }
      return new Promise((resolve, reject) => {
        cloudinary.uploader
          .upload_stream(
            {
              resource_type: 'image',
              type: 'authenticated',
              public_id: 'corex/avatars/' + userId + '/' + randomUUID()
            },
            (error, result) => {
              if (error)
                return reject(
                  new ApiError(
                    502,
                    'Photo upload failed. Check Cloudinary configuration and retry.'
                  )
                );
              resolve({ publicId: result.public_id, version: result.version });
            }
          )
          .end(buffer);
      });
    },
    async remove(publicId) {
      if (enabled && publicId)
        await cloudinary.uploader.destroy(publicId, {
          resource_type: 'image',
          type: 'authenticated',
          invalidate: true
        });
    },
    async read(avatar) {
      if (!enabled) throw new ApiError(503, 'Cloudinary is not configured.');
      const url = cloudinary.url(avatar.publicId, {
        resource_type: 'image',
        type: 'authenticated',
        secure: true,
        sign_url: true,
        version: avatar.version,
        format: 'webp'
      });
      const response = await fetch(url, { signal: AbortSignal.timeout(15000) });
      if (!response.ok) throw new ApiError(502, 'Profile photo is temporarily unavailable.');
      return Buffer.from(await response.arrayBuffer());
    }
  };
}
