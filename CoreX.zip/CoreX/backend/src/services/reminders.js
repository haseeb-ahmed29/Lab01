import Reminder from '../models/Reminder.js';
import User from '../models/User.js';
import { localDate } from '../utils/dates.js';
import { notify } from './notifications.js';

export async function runReminders(email, now = new Date()) {
  const cursor = Reminder.find({ enabled: true }).cursor();
  for await (const reminder of cursor) {
    const user = await User.findById(reminder.userId);
    if (!user) continue;
    const timezone = user.settings.timezone;
    const date = localDate(timezone, now);
    const day = new Date(date + 'T12:00:00Z').getUTCDay();
    const time = new Intl.DateTimeFormat('en-GB', {
      timeZone: timezone,
      hour: '2-digit',
      minute: '2-digit',
      hourCycle: 'h23'
    }).format(now);
    if (!reminder.days.includes(day) || time < reminder.time) continue;
    const claimed = await Reminder.findOneAndUpdate(
      {
        _id: reminder._id,
        enabled: true,
        lastSentDate: { $ne: date }
      },
      { lastSentDate: date }
    );
    if (!claimed) continue;
    await notify(
      user,
      'reminder',
      reminder.title,
      'Scheduled for ' + reminder.time + ' · ' + timezone,
      '/settings?tab=reminders',
      'reminder:' + reminder._id + ':' + date
    );
    if (
      reminder.email &&
      user.settings.notifications.email &&
      email.enabled &&
      user.emailVerifiedAt
    ) {
      try {
        await email.send(
          user.email,
          'CoreX reminder · ' + reminder.title,
          reminder.title + '\nScheduled for ' + reminder.time + ' (' + timezone + ').'
        );
      } catch {
        console.error('Reminder email failed. The in-app notification is available.');
      }
    }
  }
}

export function startReminderWorker(email) {
  let running = false;
  const tick = async () => {
    if (running) return;
    running = true;
    try {
      await runReminders(email);
    } catch {
      console.error('Reminder worker will retry on its next tick.');
    } finally {
      running = false;
    }
  };
  const timer = setInterval(tick, 30000);
  timer.unref();
  tick();
  return () => clearInterval(timer);
}
