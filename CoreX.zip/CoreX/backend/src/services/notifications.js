import { randomUUID } from 'node:crypto';
import Notification from '../models/Notification.js';
import Workout from '../models/Workout.js';
import { addDays, weekStart } from '../utils/dates.js';

export async function notify(user, type, title, message, link, eventKey = randomUUID()) {
  if (!user.settings.notifications[type]) return;
  try {
    await Notification.updateOne(
      { eventKey },
      {
        $setOnInsert: { userId: user._id, type, title, message, link, eventKey }
      },
      { upsert: true }
    );
  } catch (error) {
    if (error.code !== 11000) console.error('Notification could not be saved.');
  }
}

export async function workoutNotifications(user, workout, wasCompleted) {
  if (workout.kind !== 'session' || workout.status !== 'completed' || wasCompleted) return;
  await notify(
    user,
    'workout',
    'Workout completed',
    workout.title + ' has been logged.',
    '/workouts',
    'workout:' + workout._id
  );
  const start = weekStart(workout.date);
  const count = await Workout.countDocuments({
    userId: user._id,
    kind: 'session',
    status: 'completed',
    date: { $gte: start, $lte: addDays(start, 6) }
  });
  if (count >= user.goals.weeklyWorkouts) {
    await notify(
      user,
      'goal',
      'Weekly goal reached',
      'You reached your target of ' + user.goals.weeklyWorkouts + ' workouts.',
      '/progress',
      'goal:' + user._id + ':' + start
    );
  }
}
