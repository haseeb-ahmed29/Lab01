import mongoose from 'mongoose';
const schema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    title: String,
    type: String,
    time: String,
    days: [Number],
    enabled: { type: Boolean, default: true },
    email: { type: Boolean, default: false },
    lastSentDate: String
  },
  { timestamps: true }
);
schema.index({ enabled: 1 });
export default mongoose.model('Reminder', schema);
