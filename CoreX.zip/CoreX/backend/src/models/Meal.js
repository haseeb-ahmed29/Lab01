import mongoose from 'mongoose';
const schema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    date: String,
    mealType: String,
    notes: String,
    foods: [
      {
        name: String,
        quantity: String,
        calories: Number,
        protein: Number,
        carbs: Number,
        fat: Number
      }
    ],
    calories: Number,
    protein: Number,
    carbs: Number,
    fat: Number
  },
  { timestamps: true }
);
schema.index({ userId: 1, date: -1 });
export default mongoose.model('Meal', schema);
