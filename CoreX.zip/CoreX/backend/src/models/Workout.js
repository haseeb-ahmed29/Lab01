import mongoose from 'mongoose';
const schema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    kind: { type: String, enum: ['session', 'routine'], required: true },
    title: String,
    date: String,
    category: String,
    tags: [String],
    notes: String,
    status: { type: String, enum: ['planned', 'completed'], default: 'completed' },
    duration: Number,
    exercises: [
      {
        name: String,
        sets: Number,
        reps: Number,
        weightKg: Number,
        distanceKm: Number,
        minutes: Number,
        notes: String
      }
    ]
  },
  { timestamps: true }
);
schema.index({ userId: 1, kind: 1, date: -1 });
export default mongoose.model('Workout', schema);
