import mongoose from 'mongoose';
const schema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    type: String,
    title: String,
    message: String,
    link: String,
    read: { type: Boolean, default: false },
    eventKey: { type: String, required: true, unique: true }
  },
  { timestamps: true }
);
schema.index({ userId: 1, createdAt: -1 });
export default mongoose.model('Notification', schema);
