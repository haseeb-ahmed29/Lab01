export class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

export function requireResult(value, message = 'Record not found.') {
  if (!value) throw new ApiError(404, message);
  return value;
}
