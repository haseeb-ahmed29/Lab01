export function localDate(timeZone = 'Asia/Karachi', value = new Date()) {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(value);
}

export function addDays(date, days) {
  const value = new Date(date + 'T12:00:00Z');
  value.setUTCDate(value.getUTCDate() + days);
  return value.toISOString().slice(0, 10);
}

export function weekStart(date) {
  const day = new Date(date + 'T12:00:00Z').getUTCDay();
  return addDays(date, -(day === 0 ? 6 : day - 1));
}

export function dayRange(start, end) {
  const dates = [];
  for (let date = start; date <= end; date = addDays(date, 1)) dates.push(date);
  return dates;
}

export function dateFilter(query) {
  const date = {};
  if (query.from) date.$gte = query.from;
  if (query.to) date.$lte = query.to;
  return Object.keys(date).length ? { date } : {};
}

export const literalRegex = (text) => text.replace(/[.*+?^$\{\}()|[\]\\]/g, '\\$&');

export function pagination(query) {
  return {
    page: query.page || 1,
    limit: query.limit || 20,
    skip: ((query.page || 1) - 1) * (query.limit || 20)
  };
}
