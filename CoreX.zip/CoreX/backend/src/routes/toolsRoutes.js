import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { validate, validateQuery, validId } from '../middleware/validate.js';
import { reminderSchema, supportSchema, postSchema, replySchema } from '../validators/index.js';
import * as tools from '../controllers/toolsController.js';
import * as community from '../controllers/communityController.js';
import { report } from '../controllers/reportController.js';
export default function toolsRoutes(deps) {
  const router = Router();
  router.get('/reminders', tools.listReminders);
  router.post('/reminders', validate(reminderSchema), tools.createReminder);
  router.put('/reminders/:id', validId, validate(reminderSchema), tools.updateReminder);
  router.delete('/reminders/:id', validId, tools.deleteReminder);
  router.get('/notifications', tools.listNotifications);
  router.patch('/notifications/read-all', tools.markAllNotifications);
  router.patch('/notifications/:id/read', validId, tools.markNotification);
  router.get('/reports', validateQuery, report);
  router.post(
    '/support',
    rateLimit({ windowMs: 3600000, limit: 10, message: { message: 'Please try again later.' } }),
    validate(supportSchema),
    tools.supportController(deps)
  );
  router.get('/community/people', validateQuery, community.searchPeople);
  router.post('/community/people/:id/follow', validId, community.followPerson);
  router.delete('/community/people/:id/follow', validId, community.unfollowPerson);
  router.get('/community/posts', validateQuery, community.listPosts);
  router.post('/community/posts', validate(postSchema), community.createPost);
  router.delete('/community/posts/:id', validId, community.deletePost);
  router.post(
    '/community/posts/:id/replies',
    validId,
    validate(replySchema),
    community.createReply
  );
  router.delete('/community/replies/:id', validId, community.deleteReply);
  return router;
}
