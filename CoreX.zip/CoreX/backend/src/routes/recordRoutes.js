import { Router } from 'express';
import { validate, validateQuery, validId } from '../middleware/validate.js';
export function recordRoutes(controller, schema) {
  const router = Router();
  router.get('/', validateQuery, controller.list);
  router.post('/', validate(schema), controller.create);
  router.put('/:id', validId, validate(schema), controller.update);
  router.delete('/:id', validId, controller.remove);
  return router;
}
