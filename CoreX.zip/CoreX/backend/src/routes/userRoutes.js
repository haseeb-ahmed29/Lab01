import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { userController } from '../controllers/userController.js';
import { validate, validId } from '../middleware/validate.js';
import { profileSchema, passwordSchema, preferencesSchema } from '../validators/index.js';
export default function userRoutes(deps) {
  const router = Router();
  const c = userController(deps);
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 5 * 1024 * 1024, files: 1, fields: 0 }
  });
  router.patch('/me', validate(profileSchema), c.profile);
  router.patch('/me/preferences', validate(preferencesSchema), c.preferences);
  router.patch('/me/password', validate(passwordSchema), c.password);
  router.post('/me/avatar', upload.single('avatar'), c.uploadAvatar);
  router.delete('/me/avatar', c.deleteAvatar);
  router.delete(
    '/me',
    validate(z.object({ password: z.string().min(1).max(128) })),
    c.deleteAccount
  );
  router.get('/:id/avatar', validId, c.avatar);
  return router;
}
