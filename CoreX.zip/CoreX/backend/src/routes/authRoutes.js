import { Router } from 'express';
import { z } from 'zod';
import rateLimit from 'express-rate-limit';
import { authController } from '../controllers/authController.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { registerSchema, loginSchema, emailSchema, resetSchema } from '../validators/index.js';
export default function authRoutes(deps) {
  const router = Router();
  const controller = authController(deps);
  const limited = rateLimit({
    windowMs: 15 * 60000,
    limit: deps.config.nodeEnv === 'test' ? 1000 : 30,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { message: 'Too many attempts. Try again in 15 minutes.' }
  });
  const emailLimited = rateLimit({
    windowMs: 15 * 60000,
    limit: deps.config.nodeEnv === 'test' ? 1000 : 5,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { message: 'Please wait before requesting another email.' }
  });
  router.get('/session', controller.session);
  router.post('/register', limited, validate(registerSchema), controller.register);
  router.post('/login', limited, validate(loginSchema), controller.login);
  router.post('/logout', controller.logout);
  router.post('/forgot-password', emailLimited, validate(emailSchema), controller.forgot);
  router.post('/reset-password', limited, validate(resetSchema), controller.reset);
  router.post('/verification', requireAuth, emailLimited, controller.requestVerification);
  router.post(
    '/verify-email',
    limited,
    validate(z.object({ token: z.string().regex(/^[a-f0-9]{64}$/) })),
    controller.verifyEmail
  );
  return router;
}
