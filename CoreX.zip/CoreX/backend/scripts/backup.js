import mongoose from 'mongoose';
import { mkdir, writeFile, chmod } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { getConfig } from '../src/config/env.js';
import { connectDatabase } from '../src/config/database.js';
// Logical JSON snapshot. Use Atlas managed backups for production recovery.
try {
  const config = getConfig();
  await connectDatabase(config.mongoUri);
  const directory = path.join(
    fileURLToPath(new URL('../../backups/', import.meta.url)),
    new Date().toISOString().replaceAll(':', '-')
  );
  await mkdir(directory, { recursive: true, mode: 0o700 });
  const collections = await mongoose.connection.db.listCollections().toArray();
  for (const collection of collections) {
    if (
      ['sessions', 'authtokens'].includes(collection.name) ||
      collection.name.startsWith('system.')
    )
      continue;
    const records = await mongoose.connection.db.collection(collection.name).find({}).toArray();
    const file = path.join(directory, collection.name + '.json');
    await writeFile(file, mongoose.mongo.BSON.EJSON.stringify(records, { relaxed: false }), {
      mode: 0o600
    });
    await chmod(file, 0o600);
  }
  console.log(
    'Logical snapshot saved to ' +
      directory +
      '. Protect it: it includes personal records and password hashes.'
  );
} catch (error) {
  console.error('Backup failed: ' + error.message);
  process.exitCode = 1;
} finally {
  await mongoose.disconnect();
}
