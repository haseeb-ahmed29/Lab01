import mongoose from 'mongoose';
import { getConfig } from '../src/config/env.js';
import { connectDatabase } from '../src/config/database.js';
import { seedDemo } from '../src/services/seedData.js';
try {
  const config = getConfig();
  const email = process.env.SEED_EMAIL?.trim().toLowerCase(),
    password = process.env.SEED_PASSWORD;
  if (!email || !password || password.length < 10)
    throw new Error(
      'Set SEED_EMAIL and a SEED_PASSWORD of at least 10 characters in backend/.env.'
    );
  await connectDatabase(config.mongoUri);
  const user = await seedDemo({
    email,
    password,
    username: process.env.SEED_USERNAME || 'corex_demo'
  });
  console.log(
    'Demo records created for ' + user.email + '. Sign in with the SEED_PASSWORD you set.'
  );
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
} finally {
  await mongoose.disconnect();
}
