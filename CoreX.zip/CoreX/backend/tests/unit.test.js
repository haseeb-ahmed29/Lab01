import test from 'node:test';
import assert from 'node:assert/strict';
import { hashPassword, verifyPassword } from '../src/utils/password.js';
import { weekStart, addDays, localDate, literalRegex } from '../src/utils/dates.js';
import { weightStatus } from '../src/controllers/dashboardController.js';
import { csvCell } from '../src/services/reports.js';
import { date, mealSchema, workoutSchema } from '../src/validators/index.js';

test('passwords are salted, verifiable, and reject a wrong password', async () => {
  const a = await hashPassword('secure-password-123'),
    b = await hashPassword('secure-password-123');
  assert.notEqual(a, b);
  assert.equal(await verifyPassword('secure-password-123', a), true);
  assert.equal(await verifyPassword('wrong', a), false);
});
test('calendar calculations handle Sunday, month boundaries and user timezones', () => {
  assert.equal(weekStart('2026-11-22'), '2026-11-16');
  assert.equal(addDays('2026-12-31', 1), '2027-01-01');
  assert.equal(localDate('Asia/Karachi', new Date('2026-11-17T22:00:00Z')), '2026-11-18');
});
test('status compares distance to a personal goal for gain and loss goals', () => {
  assert.equal(weightStatus([{ value: 80 }, { value: 79 }], 75).tone, 'success');
  assert.equal(weightStatus([{ value: 60 }, { value: 61 }], 65).tone, 'success');
  assert.equal(weightStatus([{ value: 80 }, { value: 81 }], 75).tone, 'danger');
  assert.equal(weightStatus([{ value: 80 }, { value: 80 }], 75).tone, 'warning');
  assert.equal(weightStatus([{ value: 75.1 }], 75).label, 'At your target');
  assert.equal(weightStatus([], null).tone, 'neutral');
});
test('CSV cells escape quotes and spreadsheet formulas', () => {
  assert.equal(csvCell('a"b'), '"a""b"');
  assert.equal(csvCell('=HYPERLINK("x")'), '"\'=HYPERLINK(""x"")"');
  assert.ok(csvCell('  +SUM(1)').startsWith('"\''));
  assert.ok(csvCell('\tcommand').startsWith('"\''));
});
test('search terms are literal, not executable regular expressions', () => {
  const pattern = new RegExp(literalRegex('Bench (heavy).*'), 'i');
  assert.equal(pattern.test('Bench (heavy).*'), true);
  assert.equal(pattern.test('Bench heavy123'), false);
});
test('impossible dates and invalid nutrient values are rejected', () => {
  assert.equal(date.safeParse('2026-02-30').success, false);
  assert.equal(date.safeParse('2024-02-29').success, true);
  assert.equal(
    mealSchema.safeParse({
      date: '2026-11-17',
      mealType: 'lunch',
      foods: [{ name: 'Rice', quantity: '1 bowl', calories: -2, protein: 0, carbs: 1, fat: 0 }]
    }).success,
    false
  );
  assert.equal(
    workoutSchema.safeParse({
      kind: 'session',
      title: 'Empty',
      date: '2026-11-17',
      category: 'strength',
      status: 'completed',
      duration: 20,
      exercises: []
    }).success,
    false
  );
});
