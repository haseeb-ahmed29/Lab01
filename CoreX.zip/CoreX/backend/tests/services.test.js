import test from 'node:test';
import assert from 'node:assert/strict';
import { Writable } from 'node:stream';
import sharp from 'sharp';
import { v2 as cloudinary } from 'cloudinary';
import { createMediaService } from '../src/services/cloudinary.js';
import { createEmailService } from '../src/services/email.js';

test('unconfigured external services fail clearly without pretending to upload or send', async () => {
  const media = createMediaService({});
  await assert.rejects(media.uploadAvatar({ buffer: Buffer.from('image') }, 'user'), {
    status: 503
  });
  assert.throws(() => createEmailService({}).requireConfigured(), { status: 503 });
});
test('avatar service rejects invalid image bytes before calling Cloudinary', async () => {
  const media = createMediaService({ cloud_name: 'test', api_key: 'test', api_secret: 'test' });
  await assert.rejects(
    media.uploadAvatar({ buffer: Buffer.from('<svg>not an accepted raster image</svg>') }, 'user'),
    { status: 400 }
  );
  await assert.rejects(media.uploadAvatar(null, 'user'), { status: 400 });
});
test('avatar processing emits 400x400 WebP and requests authenticated Cloudinary delivery', async () => {
  const original = cloudinary.uploader.upload_stream;
  let options, image;
  cloudinary.uploader.upload_stream = (settings, callback) => {
    options = settings;
    return new Writable({
      write(chunk, encoding, done) {
        image = Buffer.from(chunk);
        done();
      },
      final(done) {
        callback(null, { public_id: settings.public_id, version: 123 });
        done();
      }
    });
  };
  try {
    const media = createMediaService({ cloud_name: 'test', api_key: 'test', api_secret: 'test' });
    const input = await sharp({
      create: { width: 800, height: 600, channels: 3, background: '#FB7359' }
    })
      .png()
      .toBuffer();
    const result = await media.uploadAvatar({ buffer: input }, 'example-user');
    const metadata = await sharp(image).metadata();
    assert.equal(metadata.format, 'webp');
    assert.equal(metadata.width, 400);
    assert.equal(metadata.height, 400);
    assert.equal(options.type, 'authenticated');
    assert.equal(options.resource_type, 'image');
    assert.ok(result.publicId.startsWith('corex/avatars/example-user/'));
    assert.equal(result.version, 123);
  } finally {
    cloudinary.uploader.upload_stream = original;
  }
});
