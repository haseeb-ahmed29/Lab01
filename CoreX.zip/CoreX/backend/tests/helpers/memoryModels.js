// Controller-contract test double ONLY. This is not MongoDB and is never used by the app.
// It lets HTTP/session/validation/mail contracts run where the mongod process is unavailable.
import mongoose from 'mongoose';
import session from 'express-session';
export function installMemoryModels() {
  const tables = new Map(),
    original = [],
    refs = { userId: 'User', postId: 'Post', follower: 'User', following: 'User' };
  const clone = (value) => (value == null ? value : JSON.parse(JSON.stringify(value)));
  const scalar = (value) =>
    value && typeof value === 'object' && value._bsontype === 'ObjectId' ? value.toString() : value;
  const equal = (a, b) => String(scalar(a)) === String(scalar(b));
  function values(object, key) {
    const parts = key.split('.');
    let list = [object];
    for (const part of parts)
      list = list.flatMap((value) =>
        Array.isArray(value) ? value.map((v) => v?.[part]) : [value?.[part]]
      );
    return list.flat();
  }
  function compare(actual, expected) {
    actual = scalar(actual);
    expected = scalar(expected);
    if (expected instanceof RegExp) return expected.test(String(actual));
    if (expected && typeof expected === 'object' && !(expected instanceof Date)) {
      return Object.entries(expected).every(([operator, value]) => {
        const left =
          typeof value === 'object' && value instanceof Date ? new Date(actual).getTime() : actual;
        const right = value instanceof Date ? value.getTime() : scalar(value);
        if (operator === '$ne') return !equal(actual, value);
        if (operator === '$in') return value.some((item) => equal(actual, item));
        if (operator === '$gte') return left >= right;
        if (operator === '$lte') return left <= right;
        if (operator === '$gt') return left > right;
        if (operator === '$lt') return left < right;
        if (operator === '$regex')
          return new RegExp(value, expected.$options || '').test(String(actual));
        if (operator === '$options') return true;
        return equal(actual?.[operator], value);
      });
    }
    return equal(actual, expected);
  }
  function matches(row, query) {
    return Object.entries(query).every(([key, value]) =>
      key === '$or'
        ? value.some((q) => matches(row, q))
        : key === '$and'
          ? value.every((q) => matches(row, q))
          : values(row, key).some((actual) => compare(actual, value))
    );
  }
  function setPath(object, key, value) {
    const keys = key.split('.');
    const last = keys.pop();
    let target = object;
    for (const part of keys) target = target[part] ||= {};
    target[last] = clone(value);
  }
  function patch(row, update, insert = false) {
    for (const [key, value] of Object.entries(update)) {
      if (key === '$set' || (key === '$setOnInsert' && insert))
        Object.entries(value).forEach(([k, v]) => setPath(row, k, v));
      else if (key === '$unset')
        Object.keys(value).forEach((k) => {
          const keys = k.split('.');
          const last = keys.pop();
          let target = row;
          for (const part of keys) target = target?.[part];
          if (target) delete target[last];
        });
      else if (key === '$inc')
        Object.entries(value).forEach(([k, v]) => setPath(row, k, (row[k] || 0) + v));
      else if (!key.startsWith('$')) setPath(row, key, value);
    }
    row.updatedAt = new Date().toISOString();
    return row;
  }
  function project(row, selection) {
    if (!row || !selection) return row;
    const fields = selection.split(' ').filter(Boolean),
      include = fields.filter((field) => !field.startsWith('-') && !field.startsWith('+'));
    let result = include.length
      ? Object.fromEntries(
          ['_id', ...include].filter((key) => key in row).map((key) => [key, row[key]])
        )
      : { ...row };
    fields
      .filter((field) => field.startsWith('-'))
      .forEach((field) => delete result[field.slice(1)]);
    return result;
  }
  function document(model, value) {
    if (value == null) return null;
    const doc = model.hydrate(clone(value));
    doc.save = async () => {
      const record = clone(doc.toObject());
      tables.get(model.modelName).set(String(doc._id), record);
      return doc;
    };
    return doc;
  }
  function duplicate(model, row, except) {
    const unique =
      model.modelName === 'User'
        ? [['email'], ['username']]
        : model.modelName === 'AuthToken'
          ? [['digest'], ['userId', 'purpose']]
          : model.modelName === 'Notification'
            ? [['eventKey']]
            : model.modelName === 'Follow'
              ? [['follower', 'following']]
              : [];
    if (
      [...tables.get(model.modelName).values()].some(
        (other) =>
          other._id !== except &&
          unique.some((keys) =>
            keys.every((key) => row[key] != null && equal(row[key], other[key]))
          )
      )
    ) {
      const error = new Error('Duplicate');
      error.code = 11000;
      throw error;
    }
  }
  function create(model, input) {
    const doc = new model(input);
    const row = clone(doc.toObject());
    row.createdAt ||= new Date().toISOString();
    row.updatedAt ||= row.createdAt;
    duplicate(model, row);
    tables.get(model.modelName).set(row._id, row);
    return document(model, row);
  }
  class Query {
    constructor(model, fn, many = false) {
      this.model = model;
      this.fn = fn;
      this.many = many;
      this.offset = 0;
      this.maximum = Infinity;
      this.population = [];
    }
    sort(value) {
      this.order = value;
      return this;
    }
    skip(value) {
      this.offset = value;
      return this;
    }
    limit(value) {
      this.maximum = value;
      return this;
    }
    select(value) {
      this.selection = value;
      return this;
    }
    lean() {
      this.plain = true;
      return this;
    }
    session() {
      return this;
    }
    populate(key, select) {
      this.population.push({ key, select });
      return this;
    }
    async exec() {
      let value = await this.fn();
      if (typeof value === 'number' || typeof value === 'boolean') return value;
      let list = this.many ? value : value ? [value] : [];
      if (this.order)
        list.sort((a, b) => {
          for (const [key, direction] of Object.entries(this.order)) {
            if (a[key] > b[key]) return direction;
            if (a[key] < b[key]) return -direction;
          }
          return 0;
        });
      list = list
        .slice(this.offset, this.offset + this.maximum)
        .map((row) => project(clone(row), this.selection));
      for (const row of list)
        for (const { key, select } of this.population)
          row[key] = project(clone(tables.get(refs[key])?.get(String(row[key])) || null), select);
      const result = list.map((row) =>
        this.plain || this.population.length ? row : document(this.model, row)
      );
      return this.many ? result : result[0] || null;
    }
    then(resolve, reject) {
      return this.exec().then(resolve, reject);
    }
    cursor() {
      const self = this;
      return {
        async *[Symbol.asyncIterator]() {
          for (const value of await self.exec()) yield value;
        }
      };
    }
  }
  for (const model of Object.values(mongoose.models)) {
    tables.set(model.modelName, new Map());
    const methods = {
      init: async () => model,
      create: async (input) =>
        Array.isArray(input) ? input.map((row) => create(model, row)) : create(model, input),
      insertMany: async (input) => input.map((row) => create(model, row)),
      find: (query = {}) =>
        new Query(
          model,
          () => [...tables.get(model.modelName).values()].filter((row) => matches(row, query)),
          true
        ),
      findOne: (query = {}) =>
        new Query(model, () =>
          [...tables.get(model.modelName).values()].find((row) => matches(row, query))
        ),
      findById: (id) => methods.findOne({ _id: id }),
      countDocuments: (query = {}) =>
        new Query(
          model,
          () =>
            [...tables.get(model.modelName).values()].filter((row) => matches(row, query)).length
        ),
      exists: async (query) =>
        [...tables.get(model.modelName).values()].some((row) => matches(row, query)),
      findOneAndUpdate: (query, update, options = {}) =>
        new Query(model, () => {
          const table = tables.get(model.modelName);
          const found = [...table.values()].find((row) => matches(row, query));
          if (!found && !options.upsert) return null;
          if (!found) {
            const input = Object.fromEntries(
              Object.entries(query).filter(
                ([key, value]) =>
                  !key.startsWith('$') && (typeof value !== 'object' || value?._bsontype)
              )
            );
            const row = patch(input, update, true);
            const doc = create(model, row);
            return options.new ? clone(doc.toObject()) : null;
          }
          const previous = clone(found),
            changed = patch(clone(found), update);
          duplicate(model, changed, found._id);
          table.set(found._id, changed);
          return options.new ? changed : previous;
        }),
      findByIdAndUpdate: (id, update, options) =>
        methods.findOneAndUpdate({ _id: id }, update, options),
      findOneAndDelete: (query) =>
        new Query(model, () => {
          const table = tables.get(model.modelName),
            found = [...table.values()].find((row) => matches(row, query));
          if (found) table.delete(found._id);
          return found;
        }),
      deleteMany: async (query) => {
        let count = 0;
        const table = tables.get(model.modelName);
        for (const [id, row] of table)
          if (matches(row, query)) {
            table.delete(id);
            count++;
          }
        return { deletedCount: count };
      },
      deleteOne: async (query) => ({
        deletedCount: (await methods.findOneAndDelete(query)) ? 1 : 0
      }),
      updateOne: async (query, update, options = {}) => {
        const exists = await methods.exists(query);
        await methods.findOneAndUpdate(query, update, options);
        return { upsertedCount: !exists && options.upsert ? 1 : 0, modifiedCount: exists ? 1 : 0 };
      },
      updateMany: async (query, update) => {
        const rows = await methods.find(query).lean();
        for (const row of rows) await methods.findByIdAndUpdate(row._id, update);
        return { modifiedCount: rows.length };
      }
    };
    for (const [name, fn] of Object.entries(methods)) {
      original.push([model, name, model[name]]);
      model[name] = fn;
    }
  }
  original.push([mongoose.connection, 'transaction', mongoose.connection.transaction]);
  mongoose.connection.transaction = async (callback) => callback({});
  const store = new session.MemoryStore();
  store.close = async () => {};
  return {
    store,
    restore() {
      for (const [object, name, value] of original) object[name] = value;
    }
  };
}
