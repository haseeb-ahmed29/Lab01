# CoreX — Fit Zone

A complete MERN academy project for personal fitness tracking. Coral and white responsive UI, four main sections on desktop/mobile, collapsible desktop sidebar, replaceable local assets, MongoDB Atlas, Cloudinary profile photos and SMTP email.

**Pehle yeh read karein:** application ka code included hai, lekin aapke Atlas, Cloudinary aur SMTP credentials included nahi hain. Apne credentials `backend/.env` mein add karein. Project abhi localhost ke liye configured hai.

## 1. Kya included hai?

- Register, username/email login, logout, secure server sessions, forgot/reset password and email verification.
- Private dashboard with weekly workouts, active time, calories, weight and charts.
- Workout sessions and reusable routines: exercises, sets, reps, weight, distance, time, notes, tags, search and filters.
- Meal logs: foods, quantities, calories, protein, carbs and fat; automatic totals and calorie chart.
- Weight, body measurements, run times and lift history with graphs.
- Profile/name/email/password/photo editing; metric/imperial units, light/dark theme, timezone and personal goals.
- Notifications, scheduled reminders, PDF/CSV/JSON reports, support/feedback.
- Optional community search, follows, posts and replies, because the Word brief includes these. **Every profile starts private.** Fitness records are never shared by following someone.
- Mobile bottom navigation: **Dashboard, Workouts, Meals, Progress**. Desktop has exactly the same four main sections. Extra tools are in the profile menu / Settings.

## 2. Requirements

Install **Node.js 24 LTS** (Node 22.12+ also satisfies the declared minimum) and npm. You do **not** need to install MongoDB locally when using Atlas.

Accounts needed:

1. MongoDB Atlas — required to save data and login sessions.
2. Cloudinary — needed for profile photo uploads.
3. An SMTP provider — needed for reset/verification emails, email reminders and support delivery.

Internet is required for package installation and those cloud services. Browser fonts, logo and the login image are local assets.

## 3. Quick setup — Roman Urdu

1. ZIP extract karein. `CoreX` folder VS Code mein open karein.
2. Terminal **CoreX root** mein open karein, jahan root `package.json` hai:

   ```bash
   npm install
   ```

   Ek hi command frontend aur backend dono ki dependencies install karti hai. `node_modules` ZIP mein intentionally nahi hai.

3. `backend/.env` open karein. Placeholder MongoDB URL replace karein aur session secret add karein. `.env.example` bhi reference ke liye included hai.
4. Session secret banane ke liye terminal mein run karein:

   ```bash
   node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"
   ```

   Output ko `SESSION_SECRET=` ke aage paste karein. Apna secret publicly share na karein.

5. Cloudinary aur SMTP values neeche diye gaye tables ke mutabiq fill karein.
6. App start karein:

   ```bash
   npm run dev
   ```

7. Browser mein **http://localhost:5173** open karein. **Create an account** par click karke apna account banayein.

Backend **http://localhost:5000** par chalega. API health URL: **http://localhost:5000/api/health**. Terminal band karne se server aur reminders band ho jate hain. Stop karne ke liye `Ctrl+C`.

## 4. MongoDB Atlas setup

1. Atlas project mein database deployment / cluster create karein.
2. Database Access mein **database user** banayein. Yeh aapke Atlas website login se alag hai. `corex` database ke liye `readWrite` permission dein.
3. Network Access / IP Access List mein **apna current public IP** add karein. IP change ho to yahan update karein.
4. Cluster → Connect → Drivers → Node.js se connection string copy karein.
5. Database name `corex` set karein. Example:

   ```dotenv
   MONGODB_URI=mongodb+srv://DB_USER:ENCODED_PASSWORD@YOUR_CLUSTER.mongodb.net/corex?retryWrites=true&w=majority
   ```

6. Password ke special characters URI-encode karein. Example: `@` becomes `%40`. Raw credentials README ya frontend mein paste na karein.

Atlas replica sets support the transaction used when deleting an entire account. If you choose local MongoDB later, use a replica set; a standalone server cannot run that transaction.

Official guide: https://www.mongodb.com/docs/atlas/driver-connection/

## 5. Backend `.env` — kya fill karna hai?

| Variable | Aap kya add karein |
|---|---|
| `NODE_ENV` | Localhost par `development` rehne dein. |
| `PORT` | `5000` default. Agar badlein to frontend proxy bhi update karein. |
| `CLIENT_URL` | Local dev ke liye `http://localhost:5173`, trailing slash ke baghair. Email links aur allowed browser origin is se bante hain. |
| `MONGODB_URI` | Apna Atlas database connection string. |
| `SESSION_SECRET` | Upar wali command se generated random secret. Minimum 32 characters. |
| `CLOUDINARY_CLOUD_NAME` | Cloudinary dashboard ka Cloud name. |
| `CLOUDINARY_API_KEY` | Cloudinary API key. |
| `CLOUDINARY_API_SECRET` | Cloudinary API secret; backend mein hi rakhein. |
| `SMTP_HOST` | Provider ka SMTP hostname. |
| `SMTP_PORT` | Usually `587` or `465`, provider ke mutabiq. |
| `SMTP_SECURE` | Port 587: `false`; port 465: `true`. |
| `SMTP_REQUIRE_TLS` | Real provider ke liye `true`. |
| `SMTP_USER` | SMTP username, account email or provider-supplied username. |
| `SMTP_PASS` | SMTP password / app password / provider credential. |
| `SMTP_FROM` | Verified sender, e.g. `CoreX <you@yourdomain.com>`. |
| `SUPPORT_EMAIL` | Aapka support inbox, jo feedback receive karega. |
| `SEED_EMAIL` | Optional demo account email, sirf seed command ke liye. |
| `SEED_PASSWORD` | Optional demo password, minimum 10 characters. |
| `SEED_USERNAME` | Optional; default `corex_demo`. |

`.env` change karne ke baad backend restart karein. No secrets belong in `frontend/.env` or variables beginning with `VITE_`.

### Cloudinary details

Cloudinary console ke API Keys section se three values copy karein. No unsigned upload preset is required: the backend signs uploads with its API secret.

Profile images are validated as real JPG/PNG/WebP files, limited to 5 MB and 25 megapixels, normalized to 400×400 WebP, and uploaded as **authenticated** media under `corex/avatars/USER_ID/`. The browser reads the photo through an authenticated backend route. Old photos are removed on replacement where the remote service permits it. Failures are logged for retry/cleanup.

Guide: https://cloudinary.com/documentation/node_image_and_video_upload

### SMTP details

Example for a provider using STARTTLS:

```dotenv
SMTP_HOST=smtp.your-provider.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_REQUIRE_TLS=true
SMTP_USER=your-smtp-user
SMTP_PASS=your-smtp-password
SMTP_FROM=CoreX <your-verified-sender@example.com>
SUPPORT_EMAIL=your-support-inbox@example.com
```

Port 465 use kar rahe hain to `SMTP_PORT=465` aur `SMTP_SECURE=true` karein. Gmail/other providers may require an app password or a provider-specific SMTP credential; follow your provider’s current setup instructions. Inbox placement also depends on verified sender/domain settings and spam filtering.

Email features: welcome email, reset link (30 minutes), verification link (24 hours), opted-in verified-address reminders and support messages. Without SMTP, registration and personal tracking still work; email-dependent actions explain that delivery is unavailable. Support messages remain saved even if delivery fails.

Guide: https://nodemailer.com/smtp

## 6. Frontend environment

Included `frontend/.env`:

```dotenv
VITE_API_BASE=/api
API_PROXY_TARGET=http://localhost:5000
```

Vite proxies `/api` to Express so browser cookies stay on the same origin. Use `localhost` consistently; switching to `127.0.0.1` without updating `CLIENT_URL` can cause origin/cookie errors.

## 7. Folder guide — kis folder mein kya hai?

| Folder / file | Purpose |
|---|---|
| `backend/src/server.js` | Startup, database connection, reminder worker and shutdown. |
| `backend/src/app.js` | Express middleware and route registration. |
| `backend/src/config/` | Environment and database connection. |
| `backend/src/models/` | Mongoose schemas. |
| `backend/src/routes/` | API URLs and validation. |
| `backend/src/controllers/` | Request handling / business operations. |
| `backend/src/services/` | Email, Cloudinary, reports, reminders and notifications. |
| `backend/src/middleware/` | Authentication, CSRF, validation and error handling. |
| `backend/src/validators/` | Accepted input rules. |
| `backend/src/utils/` | Password hashing, dates and errors. |
| `backend/tests/` | Unit, HTTP-contract and MongoDB integration tests. |
| `backend/scripts/` | Syntax checks, optional demo seed and logical backup. |
| `frontend/src/pages/` | Dashboard, workouts, meals, progress and auth pages. |
| `frontend/src/pages/settings/` | Separate profile, goals, reminders, reports, community and support screens. |
| `frontend/src/components/forms/` | Separate workout, meal and progress forms. |
| `frontend/src/components/` | Shared UI elements, dialogs, logo and charts. |
| `frontend/src/layouts/` | Login layout and responsive app shell. |
| `frontend/src/context/` | Login state and toast messages. |
| `frontend/src/hooks/` | Shared API data loading hook. |
| `frontend/src/lib/` | API requests, dates and unit conversion. |
| `frontend/src/styles/global.css` | All colors, responsive layout and component styling. |
| `frontend/src/assets/brand/corex-logo.png` | Your supplied logo, original file. |
| `frontend/src/assets/images/training.png` | Local login/register background image. |
| `docs/` | User guide, API/architecture, brief mapping, test report and demo walkthrough. |

## 8. Logo aur colors change karna

- Same logo filename replace kar dein: `frontend/src/assets/brand/corex-logo.png`.
- The supplied logo includes large margins. `Brand.jsx` displays it inside a CSS frame; `.brand img` in `global.css` controls that crop. A tightly cropped replacement needs `.brand img { position: static; width: 100%; height: 100%; object-fit: contain; }`.
- Replace `assets/images/training.png` to change the auth image. For another filename update the import in `layouts/AuthLayout.jsx`.
- Main palette lives in `:root` at the start of `global.css`: coral `#FB7359`, paper `#F7F8FC`, white cards, readable dark text. Green, yellow and red have separate accessible text/background variables.
- Edit actions are yellow, completed states green and delete/error states red. Weight status compares distance to your own target; it never labels someone medically fit/unfit.

## 9. Optional demo records

Charts dekhne ke liye `backend/.env` mein `SEED_EMAIL` aur `SEED_PASSWORD` set karein, phir:

```bash
npm run seed
```

Seed ek **naya private demo account** aur sample records banata hai. Existing accounts overwrite nahi karta. Us email/password se login karein. Default demo username: `corex_demo`. Sample values are illustrative, not a diet or exercise prescription.

Normal registration creates an empty account; it does not inject demo data.

## 10. Commands and checks

```bash
npm run dev              # API + React local development
npm run build            # React production bundle
npm run check            # Backend syntax + frontend build
npm run test:unit        # Logic tests, no DB required
npm run test:contracts   # Real HTTP/session/SMTP with test model doubles
npm run test:integration # Real temporary MongoDB replica set + HTTP/SMTP
npm test                 # All test suites
npm run backup           # Logical database snapshot (see below)
```

Integration tests download a MongoDB test binary on first run and use a separate temporary database; they do not connect to your Atlas account. A restricted container can block `mongod`; run the integration suite on your normal computer in that case. See **docs/TESTING.md** for actual verified checks and limits. Model doubles are imported only by contract tests, never the application.

### Run a built frontend locally

```bash
npm run build
```

Set `CLIENT_URL=http://localhost:5000` and keep `NODE_ENV=development` for local HTTP. Then:

```bash
npm start
```

Open http://localhost:5000. Express serves the built React app and API together. Do not run the Vite dev server at the same time for this mode.

## 11. Common setup problems

| Problem | Fix |
|---|---|
| App says it cannot reach API | Keep `npm run dev` terminal open. Check the backend error and `/api/health`. |
| Atlas timeout | Check current public IP access, database user permissions, cluster hostname and internet. |
| Authentication failed connecting to MongoDB | Use the database user’s password, not Atlas website password. URI-encode special characters. |
| Session secret missing | Generate the secret and put it in `backend/.env`, then restart. |
| Request origin not allowed | Use the exact `CLIENT_URL`. Keep localhost vs 127.0.0.1 consistent. |
| Photo upload unavailable | Fill all three Cloudinary values, restart backend and sign out/in to refresh service state. |
| Verification/reset email not received | Check SMTP host/port/TLS, verified sender, credentials and spam folder. Review server logs. |
| Email reminder missing | Verify your email, enable email in Preferences and in that reminder, select the correct timezone and keep backend running. |
| EADDRINUSE / port already in use | Stop the older server. If using another API port, change `PORT` and `API_PROXY_TARGET`. |
| Delete account fails on local Mongo | Use an Atlas deployment or local replica set; the deletion uses a MongoDB transaction. |
| `mongod` test process is blocked | Run tests on an unrestricted development computer. Unit/contract tests can run separately. |

## 12. Backups and deployment notes

`npm run backup` writes an owner-only logical Extended JSON snapshot to `backend/backups/DATE/`, excluding active sessions and temporary auth tokens. It contains personal data and password hashes. Keep it private, encrypted and outside any public repository. It is a maintenance snapshot, **not** a transaction-consistent managed cluster backup; stop writes while using it for a consistent academy snapshot.

For a daily local backup, create an OS scheduled task that runs `npm run backup` from the project root. On Windows Task Scheduler use your full `npm.cmd` path, arguments `run backup`, and set **Start in** to your CoreX folder. The computer must be awake. Schedule setup and Atlas managed backups are not automatically enabled by this ZIP.

This package is for localhost. Before real public deployment, configure HTTPS, production cookie settings, a known reverse proxy, production sender/domain verification, monitoring, database backups, retention, and measured capacity. The brief’s uptime/concurrency/1–2 second targets require deployment-specific load tests. Those targets are not claimed as measured here.

## 13. Read next

- `docs/USER_GUIDE.md` — everyday use in simple Roman Urdu.
- `docs/ARCHITECTURE.md` — request flow, models and security decisions.
- `docs/API.md` — endpoints and request examples.
- `docs/REQUIREMENTS.md` — mapping to your Word brief.
- `docs/TESTING.md` — what passed and what needs your credentials/environment.
- `docs/DEMO_WALKTHROUGH.md` — academy presentation and video recording script.

User-provided logo is included unchanged. The login illustration was generated for this project. DM Sans is bundled via `@fontsource/dm-sans`; other package licenses remain with their respective authors.
