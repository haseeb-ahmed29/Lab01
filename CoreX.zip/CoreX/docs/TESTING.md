# Verification report

Date: **17 November 2026**. Runtime used: Node.js 24.22.1 and npm 11.9.0.

## Observed results

| Check | Result | What this proves / limits |
|---|---|---|
| Backend JavaScript syntax | Passed | Backend source and script syntax accepted by Node. |
| React production build | Passed | Vite compiled and bundled the actual frontend. |
| Unit and service suite | **9 passed, 0 failed** | Password, date, validation, CSV, image-processing and service-configuration behavior. |
| HTTP contract suite | **19 passed, 0 failed** | Real Express routes, HTTP sessions, CSRF and local SMTP transport; database model methods and remote Cloudinary boundary are test doubles. |
| Real MongoDB integration suite | **Blocked; not passed** | Included 19 tests could not start their temporary MongoDB replica set in this restricted execution environment. |
| Dependency audit | **0 reported vulnerabilities** | Full and production npm audit results at this build date; this is not a guarantee against undisclosed issues. |
| Desktop/mobile browser smoke checks | Passed for the flows below | Actual React and Express code with disposable in-memory model fixtures; not a live Atlas test. |
| Atlas connection / transactions / persistence | Needs your credentials and environment | Not verified against a real Atlas cluster here. |
| Cloudinary live upload / retrieval / deletion | Needs your credentials | Actual image normalization and adapter contract tested; no live provider call verified. |
| Your SMTP provider / inbox delivery | Needs your credentials | Nodemailer successfully delivered to a local SMTP test server. Provider authentication, TLS and inbox placement were not tested. |

**Total passing automated checks: 28.** The 19 additional MongoDB integration tests are not included in that passing count. `npm test` includes the blocked suite and is not reported as passing in this environment.

### Why the real database tests could not run here

The downloaded `mongod` 7.0.24 test process exited with code 100 and an `open: Operation not permitted` error in this managed execution environment. A successful MongoDB connection was not established. This is a test-environment limitation, not evidence that persistence or transactions were verified. Run the included suite on a normal development machine before academy submission.

## Automated coverage

### Unit/service tests — 9

- Salted scrypt password hashes, correct password and rejection of an incorrect password.
- Week/month boundaries and user-local calendar dates.
- Distance-to-target status for both weight-gain and weight-loss goals.
- CSV quote escaping and formula-prefix protection.
- Literal search characters, impossible dates and invalid numeric inputs.
- Truthful unavailable-service responses when email/media are unconfigured.
- Invalid image bytes rejected before upload.
- Real sharp transformation to a 400×400 WebP and authenticated Cloudinary adapter parameters.

### HTTP contract tests — 19

- Registration privacy, hidden secrets, cookie flags, duplicate/invalid input rejection.
- Unauthenticated requests, CSRF and foreign-origin rejection.
- Workout CRUD, search, routine exclusion, deduplicated notifications and owner isolation.
- Meal CRUD with server-computed totals and progress CRUD with input validation.
- Invalid query ranges, IDs and NoSQL-shaped inputs.
- PDF/CSV/JSON exports with owner-only records.
- Profile/preferences changes and password-protected email changes.
- Avatar route ownership, upload boundary and removal.
- Community opt-in, follows, posts/replies and restricted public fields.
- Timezone-aware reminders and repeated worker ticks.
- Notification read-state ownership.
- Email verification and reset delivered over an actual local SMTP connection, hashed single-use tokens and replay rejection.
- Support persistence and SMTP submission.
- Password changes/reset revoking previous sessions.
- Account-deletion controller behavior with a transaction double and owner-only removal. **This does not validate MongoDB transaction semantics.**

The contract test’s model adapter is confined to `backend/tests/helpers/`. Production startup always uses Mongoose and MongoDB; there is no fake-data or authentication-bypass mode in the application.

## Browser smoke checks

An external, disposable QA harness connected the real frontend and Express controllers to synthetic records. The harness is **not** included in this project. Browser records such as Alex Morgan / QA workout are illustrative. Browser auth was pre-established only in that harness; actual login, registration and reset behavior were checked in HTTP tests. The login layout was inspected visually.

Verified interactions:

1. Desktop dashboard cards and graphs rendered, and sidebar collapsed/expanded.
2. Created a workout, searched for it, changed its duration and observed the saved record.
3. Added and searched a meal; its totals appeared in the UI.
4. Added weight progress and observed its history/chart.
5. Saved dark/imperial preferences, then returned to light/metric.
6. Downloaded a PDF report through the browser.
7. Opened mobile navigation, workout form and profile settings in a 390×844 iframe viewport; no horizontal body overflow was measured (375px client/scroll width after the scrollbar).
8. Confirmed modal dismissal with Escape and associated field labels.
9. Created an active reminder and observed its repeat days and time in the list.
10. Inspected browser logs; no application error remained in the exercised flows. Browser-extension-owned messages were excluded.

After a paused session, the temporary preview server stopped and a reminder save reported a fetch error. Restarting that preview and repeating the action saved it successfully. The app’s server must remain running for all API actions.

Screenshots and the short video in `docs/previews/` document the interface. They are not evidence of production load, live cloud service connectivity or an exhaustive browser/device matrix.

## Reproduce the checks

From the project root after `npm install`:

```bash
npm run check
npm run test:unit
npm run test:contracts
npm run test:integration
npm audit
```

The integration suite uses `mongodb-memory-server` and a temporary replica set. Its first run needs a network download of a MongoDB binary. It does not use or modify your Atlas database. If your OS or antivirus blocks the process, use a supported development machine; do not confuse a blocked test runner with passing tests.

`npm test` runs all suites together. Use the three individual test commands to distinguish logic/HTTP failures from MongoDB process-start failures.

## Your live-service acceptance checks

| Action | Expected result |
|---|---|
| Set Atlas URI/session secret; start app | Terminal connects; `/api/health` responds successfully. |
| Register account A, sign out, sign back in | Private empty dashboard; session remains after refresh. |
| Create a workout, meal and weight record; restart server | Records persist and totals/charts match the stored records. |
| Register account B in another browser | Account A’s fitness records are absent. A private profile is not discoverable/followable. |
| Request verification and reset emails | Your actual inbox receives links; reused/expired links fail; old password/session fails after reset. |
| Upload a JPG/PNG/WebP, replace it and remove it | Profile image updates; old assets are cleaned up; invalid/oversized images fail clearly. |
| Change profile name/email/password | Changes persist; email change requires the current password; other sessions are revoked after password change. |
| Schedule a reminder a few minutes ahead | With server running and correct timezone, it appears once; email requires verification and both channel settings. |
| Export PDF and CSV | Files open and include only the selected user/date/category. |
| Try desktop, phone and keyboard navigation | Four main sections stay reachable; forms remain readable; focus is visible. |
| Delete a disposable account | Owned records are removed atomically on the Atlas replica set; the other account remains. |

No claim of zero bugs, medical accuracy, formal WCAG certification, production uptime, load capacity or completed live-service verification is made.
