# API reference

Base URL in development: `http://localhost:5000/api`. Browser frontend uses `/api` through the Vite proxy.

First `GET /auth/session` to receive the CSRF token and cookie. Send the cookie with requests and `X-CSRF-Token` on every POST/PUT/PATCH/DELETE. Successful login and registration return a **new** CSRF token; replace the old one. Authenticated endpoints return 401 for missing/expired sessions. Validation errors use 400, forbidden mutations 403, missing/other-owner records 404 and duplicate usernames/emails 409.

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Database connection readiness. |
| GET | `/auth/session` | Current user, CSRF token and integration availability. |
| POST | `/auth/register` | name, username, email, password, consent=true. |
| POST | `/auth/login` | identifier (username/email), password. |
| POST | `/auth/logout` | Destroy current session. |
| POST | `/auth/forgot-password` | email; generic response avoids revealing account existence. |
| POST | `/auth/reset-password` | token, password. |
| POST | `/auth/verification` | Request verification email (authenticated). |
| POST | `/auth/verify-email` | token. |
| PATCH | `/users/me` | name, username, email, discoverable, currentPassword when changing email. |
| PATCH | `/users/me/password` | currentPassword, newPassword. |
| PATCH | `/users/me/preferences` | units, theme, timezone, notification switches, goals. |
| POST | `/users/me/avatar` | Multipart form, field `avatar`, maximum 5 MB. |
| DELETE | `/users/me/avatar` | Remove profile photo. |
| GET | `/users/:id/avatar` | Authorized image bytes. |
| DELETE | `/users/me` | password confirmation; remove account and owned records. |
| GET/POST | `/workouts` | List/create own workouts/routines. |
| PUT/DELETE | `/workouts/:id` | Replace/delete own workout. |
| GET/POST | `/meals` | List/create own meals. |
| PUT/DELETE | `/meals/:id` | Replace/delete own meal. |
| GET/POST | `/progress` | List/create own measurements. |
| PUT/DELETE | `/progress/:id` | Replace/delete own measurement. |
| GET | `/dashboard` | Personal summary/charts; optional from/to, up to 366 days. |
| GET/POST | `/reminders` | List/create own reminders. |
| PUT/DELETE | `/reminders/:id` | Replace/delete own reminder. |
| GET | `/notifications` | Latest 50 notifications + unread count. |
| PATCH | `/notifications/read-all` | Mark own notifications read. |
| PATCH | `/notifications/:id/read` | Mark one owned notification read. |
| GET | `/reports` | format=pdf/csv/json; type=all/workouts/nutrition/progress; optional from/to. |
| POST | `/support` | topic=issue/feedback/question, subject, message. |
| GET | `/community/people` | Search discoverable people; q/page/limit. |
| POST/DELETE | `/community/people/:id/follow` | Follow/unfollow. |
| GET/POST | `/community/posts` | Public-to-members posts, create when opted in. |
| DELETE | `/community/posts/:id` | Delete own post and its replies. |
| POST | `/community/posts/:id/replies` | Publish reply; body string. |
| DELETE | `/community/replies/:id` | Delete own reply. |

Record list filters: `q`, `from`, `to`, `page`, `limit` (1–100). Workout filters: `kind`, `category`, `status`. Meals: `mealType`. Progress: `metric` and exercise search via `q`.

## Workout payload

```json
{
  "kind": "session",
  "title": "Upper body",
  "date": "2026-11-17",
  "category": "strength",
  "status": "completed",
  "duration": 40,
  "tags": ["gym"],
  "notes": "Felt good",
  "exercises": [
    { "name": "Bench press", "sets": 3, "reps": 10, "weightKg": 30, "distanceKm": 0, "minutes": 0, "notes": "" }
  ]
}
```

Use `kind: "routine"` for templates. A routine does not count in dashboard totals.

## Meal payload

```json
{
  "date": "2026-11-17",
  "mealType": "lunch",
  "notes": "",
  "foods": [
    { "name": "Rice", "quantity": "1 bowl", "calories": 220, "protein": 5, "carbs": 45, "fat": 1 }
  ]
}
```

Totals are computed by the server from the food rows; incoming total fields are ignored.

## Progress payload

```json
{ "date": "2026-11-17", "metric": "weight", "value": 78.5, "exercise": "", "notes": "Morning" }
```

Metrics: weight/waist/chest/hips/runTime/lift. Lift requires exercise. Database/API values always use kg, cm, km and minutes.

## Reminder payload

```json
{ "title": "Evening workout", "type": "workout", "time": "18:00", "days": [1, 3, 5], "enabled": true, "email": false }
```

Days: 0=Sunday to 6=Saturday. Time uses the user’s saved timezone.
