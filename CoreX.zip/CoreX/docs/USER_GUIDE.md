# CoreX user guide — Roman Urdu

## Apna account

Login screen par **Create an account** select karein. Name, username, email aur minimum 10-character password enter karein. Consent checkbox read karke tick karein. Account create hote hi dashboard open ho jayega.

Aapka data personal hai. Kisi doosre account ko aapke workouts, meals ya measurements nahi dikhte. Community visibility default off hai.

## Dashboard

Dashboard par is week ke completed workouts, active minutes, aaj ki calories aur latest weight show hota hai. Chart Monday–Sunday activity dikhata hai. Weight graph last 30 days ke records dikhata hai.

Desktop par sidebar ke collapse button se sidebar chhota/bara kar sakte hain. Mobile bottom bar mein wohi four sections hain. Top profile button se settings, reports, reminders aur help milte hain.

## Workouts

**Log workout** → title, date, category, time aur exercises add karein. Har exercise ke sets, reps, weight, distance, minutes aur notes optional numeric context ke mutabiq fill karein; irrelevant numeric fields zero reh sakte hain. **Completed** workout dashboard activity mein count hota hai. **Planned** ko baad mein **Mark done** kar sakte hain.

**My routines** mein reusable template save karein. **Log this routine** nayi workout entry kholta hai; template change nahi hota. Search title, exercises aur tags par work karta hai. Yellow **Edit** aur red **Delete** actions clear hain. Delete confirmation deta hai.

## Meals

**Log meal** mein breakfast/lunch/dinner/snack choose karein. Food ka naam, quantity aur us quantity ke nutrients enter karein. Example: poori 200 g portion ke calories/macros enter karein, per-100 g values nahi jab tak quantity bhi 100 g nahi hai. CoreX values add karta hai; food name se automatically nutrition guess nahi karta.

Calories chart last 30 days ka trend dikhata hai. Food search, meal type aur dates se log filter kar sakte hain.

## Progress

Weight, waist, chest, hips, fixed-route run time aur personal lifts record karein. Lift ke liye exercise name required hai. Har lift ka graph separately choose kar sakte hain; bench press aur squat mix nahi hote. Same route use karein jab running time compare karein.

Chart page par available latest 100 entries dikhata hai. Older pages available hain. Full records Reports se export ho sakte hain.

## Settings

- **My profile:** name, username, email, photo aur password. Email change karne ke liye current password required hai. Password change other sessions sign out karta hai.
- **Preferences & goals:** theme, kg/lb, cm/in, km/mi, timezone, workout count, calorie target aur optional weight target.
- **Reminders:** title, time, repeat days, active/paused aur optional email. Email ke liye verified address + Preferences email switch + reminder email switch required hain.
- **Reports:** PDF readable summary, CSV spreadsheet, JSON full fitness record details. Exports canonical metric units mein hain.
- **Community:** optional public name/username/photo, follows, posts and replies. Fitness records remain private. Visibility off karne par profile and published content hide ho jata hai.
- **Help & support:** FAQs, feedback and issue reporting. Support email unconfigured ho to message database mein saved rehta hai.

## Colors

Green: done / chosen goal ke qareeb. Yellow: edit / planned / holding steady. Red: delete / error / target se door. Weight trend health diagnosis nahi; user ke apne target se comparison hai.

## Password bhool jayein

**Forgot password** par apna email enter karein. Email link 30 minutes ke liye valid hai, sirf ek dafa use hota hai. New password ke baad dobara login karein. Purane sessions expire ho jate hain.

## Account delete

Settings → My profile → Delete my account. Pehle report export kar lein agar record rakhna hai. Password confirmation ke baad account aur uske records delete hote hain. Yeh action undo nahi hota.
