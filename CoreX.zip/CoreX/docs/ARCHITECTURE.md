# Architecture

## Request flow

React → same-origin `/api` → Express route → input validation → authenticated owner-scoped controller → Mongoose → MongoDB Atlas.

Vite proxies the API during development. Express serves the React production bundle when `frontend/dist` exists. Cloudinary and SMTP credentials are used only in server services.

## Models

| Model | Main purpose |
|---|---|
| User | Unique username/email, scrypt password hash, profile, settings, goals, session version. |
| Workout | Owned session/routine with exercise rows, tags, category, duration, status and date. |
| Meal | Owned food entries and server-computed nutrient totals. |
| Progress | Owned weight/measurement/run-time/lift records in canonical metric units. |
| Reminder | Owned recurring local-time schedule, days, channel preferences and last claimed day. |
| Notification | Owned in-app update with unique event key and read state. |
| AuthToken | Hashed reset/verification token, expiry, account version and email snapshot. |
| Follow | Unique follower/following pair, no access to personal fitness records. |
| Post / Reply | Explicitly published community content, hidden when its author opts out. |
| SupportTicket | Owned feedback/issue and email delivery status. |
| sessions | connect-mongo session storage with TTL. |

Dates for fitness entries are `YYYY-MM-DD`. Numeric database values use kg, cm, km and minutes. Imperial conversions happen at input/display boundaries, so changing preferences does not rewrite historical data.

## Authentication and privacy

- Passwords: Node crypto scrypt, fresh random salt, N=32768, r=8, p=3, 64-byte key; constant-time comparison.
- Session cookie: HTTP-only, SameSite=Lax, seven-day rolling expiry, Secure in production. The cookie carries an identifier, not profile data.
- Login/registration regenerate the session. Logout destroys it. Password reset increments a per-user session version to revoke all prior sessions. Password changes keep the current session but revoke the others.
- Mutating requests require a session-bound CSRF token in `X-CSRF-Token`, with an allowed Origin check. Password recovery and verification use random 32-byte tokens; only SHA-256 digests are stored. Reset tokens are single-use and expire after 30 minutes.
- Personal queries always include `userId` from the authenticated session. An incoming body cannot choose the record owner. MongoDB IDs, dates, enums, arrays and numbers are validated.
- `discoverable` defaults to false. Community responses expose only name, username, avatar and explicitly published text. Following never grants access to activity data.
- Profile photos use authenticated Cloudinary assets and an authorized proxy route. Input is decoded and re-encoded using sharp. Secrets and signed storage URLs stay server-side.
- Account deletion uses a MongoDB transaction for owned records and forum/follow cleanup. Remote image deletion happens afterward; external failure is logged.
- Helmet, request body limits, upload limits, rate limiting and literal escaped search patterns reduce common abuse. CSV cells escape spreadsheet formula prefixes.

These protections are implemented; a formal penetration test, production compliance assessment and cloud operational review have not been performed.

## Notifications and reminders

Completed sessions create deduplicated notifications. Reaching the weekly workout goal creates one notification per user/week. A 30-second worker checks reminders in each user’s timezone. An atomic `lastSentDate` update claims a reminder before delivery; a unique notification event key prevents duplicate in-app messages across workers.

Same-day missed reminders are picked up on restart. Previous days are not replayed. Email is best-effort; SMTP failures are logged and an in-app notification remains when its preference is enabled. If a process crashes after claiming a reminder but before dispatch, automatic email replay is not implemented. A durable job queue would be needed for stronger production delivery guarantees.

## Frontend

React Router defines auth and protected routes. AuthContext loads the session; API helpers attach CSRF tokens and include cookies. Mutation errors stay visible, data loading supports cancellation, dialogs use native modal focus handling and forms use associated labels. The desktop sidebar stores its collapsed preference in localStorage; mobile always has four main tabs.

Recharts uses real API records. Only complete sessions count toward activity; routine templates and planned entries do not. Personal weight status compares the latest two measurements’ distance to the chosen target. Values are not a medical evaluation.

## Extending the project

Add a Mongoose model → Zod schema → controller → route → matching frontend API form/page. Scope private queries by authenticated userId. Keep external integrations in services. Add an ownership and validation test whenever adding private data.

## Operations

The included backup script is a logical Extended JSON snapshot, not an Atlas automated backup replacement. For production, add reliable scheduled jobs, monitoring, managed backups and restore drills, retention rules, API/load tests, mail delivery monitoring, and an access-controlled support operator workflow. This academy app has no admin/trainer role or payment functionality.
