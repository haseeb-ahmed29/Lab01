const mongoose = require ("mongoose");


const Item = require ("../Models/item")

const cloudinary = require("../config/cloudinary");

//Helper function to upload an in-memory to Cloudinary using Data URI:
const uploadImageToCloudinary = async(file)=>{
    //Convert the image buffer into a Base64 string
    const b64 = Buffer.from(file.buffer).toString("base64");

    //Creates a Data URI containing the image type and Base64 data
    //file.mimetype --> image ka type batado, jaise image/png, ya image/jpeg
    const dataURI = `data:${file.mimetype};base64,${b64}`;

    //Upload the image to the "mern_items" folder in Cloudinary
    const result = await cloudinary.uploader.upload(dataURI, {
        folder: "mern_items",
    })

    //Return the upload result, including the image URL
    return result
}

//Create a new item
//route POST/api/items
